Live Alpha Trade - Setup
1. Install Node 20+ and bun (or npm).
2. bun install
3. Copy .env.example to .env and fill in your backend URL and keys.
4. Apply the database: run supabase/schema.sql and the files in supabase/migrations on your Postgres/Supabase project.
5. bun run dev   (local)   |   bun run build  (production)
Live price: Binance BTC/USDT stream (wss://stream.binance.com:9443/ws/btcusdt@trade) with REST fallbacks.
Admin access is granted via the user_roles table (role = admin).
