import { ArrowDown, ArrowUp } from "lucide-react";
import { money } from "@/lib/app-data";
import type { Tables } from "@/integrations/supabase/types";

export function TradeRow({ t }: { t: Tables<"trades"> }) {
  const up = t.side === "up";
  const chip = t.status === "win" ? "chip-up" : t.status === "loss" ? "chip-down" : t.status === "open" ? "chip-wait" : "chip-muted";
  const label = t.status === "win" ? `+${money(t.profit)}` : t.status === "loss" ? `-${money(t.amount)}` : t.status === "open" ? "Running" : "Returned";
  return (
    <div className="flex items-center gap-3 px-4 py-3">
      <div className={`flex h-9 w-9 items-center justify-center rounded-full ${up ? "chip-up" : "chip-down"}`}>{up ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}</div>
      <div className="flex-1">
        <div className="text-sm font-semibold">BTC/USDT · {up ? "Buy" : "Sell"} · {money(t.amount)}</div>
        <div className="text-xs text-muted-foreground">{new Date(t.opened_at).toLocaleString()} · {t.duration_seconds >= 60 ? `${t.duration_seconds / 60}m` : `${t.duration_seconds}s`}</div>
      </div>
      <span className={`chip ${chip}`}>{label}</span>
    </div>
  );
}

export function StatusChip({ s }: { s: string }) {
  const c = s === "approved" ? "chip-up" : s === "rejected" ? "chip-down" : "chip-wait";
  return <span className={`chip ${c} capitalize`}>{s}</span>;
}
