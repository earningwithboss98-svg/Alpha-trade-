import { useEffect, useState } from "react";

type Dot = { left: number; size: number; dur: number; delay: number; icon?: string | undefined };

function makeDots(n: number, icons: boolean): Dot[] {
  return Array.from({ length: n }, (_, i) => ({
    left: Math.random() * 100,
    size: 2 + Math.random() * 3,
    dur: 8 + Math.random() * 10,
    delay: Math.random() * 5,
    icon: icons && i % 6 === 0 ? (i % 12 === 0 ? "₿" : "₮") : undefined,
  }));
}

/** Golden dots rising bottom → top. `contained` = inside a card instead of full screen. */
export function DotParticles({ count = 25, contained = false }: { count?: number; contained?: boolean }) {
  const [dots, setDots] = useState<Dot[]>([]);
  useEffect(() => setDots(makeDots(count, !contained)), [count, contained]);
  return (
    <div aria-hidden className={`pointer-events-none overflow-hidden ${contained ? "absolute inset-0" : "fixed inset-0 z-0"}`}>
      {dots.map((d, i) =>
        d.icon ? (
          <span key={i} className={contained ? "dot-rise-in" : "dot-rise"} style={{ left: `${d.left}%`, fontSize: 8, opacity: 0.15, color: "var(--primary)", animationDuration: `${d.dur}s`, animationDelay: `${d.delay}s` }}>{d.icon}</span>
        ) : (
          <span key={i} className={`${contained ? "dot-rise-in" : "dot-rise"} dot`} style={{ left: `${d.left}%`, width: d.size, height: d.size, animationDuration: `${d.dur}s`, animationDelay: `${d.delay}s` }} />
        ),
      )}
    </div>
  );
}
