import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Bell, CandlestickChart, Download, History as HistoryIcon, House, Search, UserRound, Wallet, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useLogo, useAppName, useProfile, useUserId } from "@/lib/app-data";
import { canInstall, isStandalone, onInstallChange, promptInstall } from "@/lib/pwa";
import { Button } from "@/components/ui/button";

export function Logo({ size = 52, className = "" }: { size?: number; className?: string }) {
  const logo = useLogo();
  const name = useAppName();
  return (
    <img src={logo} alt={`${name} logo`} width={size} height={size}
      style={{ width: size, height: size }} className={`rounded-xl object-contain ${className}`} />
  );
}

export function Avatar({ size = 48, url, name }: { size?: number; url?: string | null | undefined; name?: string | null | undefined }) {
  return url ? (
    <img src={url} alt={name || "Profile"} style={{ width: size, height: size }}
      className="rounded-full border-2 border-background object-cover" />
  ) : (
    <div style={{ width: size, height: size }}
      className="flex items-center justify-center rounded-full border-2 border-background bg-card">
      <UserRound className="text-primary" style={{ width: size * 0.55, height: size * 0.55 }} />
    </div>
  );
}

const SPARKS = [
  { t: "-4%", l: "10%", d: "0s" }, { t: "8%", l: "92%", d: ".4s" }, { t: "85%", l: "-2%", d: ".9s" },
  { t: "95%", l: "70%", d: "1.3s" }, { t: "40%", l: "102%", d: ".6s" }, { t: "-6%", l: "60%", d: "1.1s" },
];

export function ShiningAvatar({ size = 72, url, name }: { size?: number; url?: string | null | undefined; name?: string | null | undefined }) {
  return (
    <div className="relative inline-block">
      <div className="gold-ring"><Avatar size={size} url={url} name={name} /></div>
      {SPARKS.map((s, i) => <span key={i} className="sparkle" style={{ top: s.t, left: s.l, animationDelay: s.d }} />)}
    </div>
  );
}

const SEARCH_ITEMS = [
  { label: "How deposit works", to: "/learning", k: "deposit usdt bep20 qr address" },
  { label: "How to withdraw", to: "/learning", k: "withdraw fee address" },
  { label: "How to trade Up / Down", to: "/learning", k: "trade buy sell up down timer" },
  { label: "What is BTC trading", to: "/learning", k: "btc bitcoin market binance" },
  { label: "BTC/USDT live chart", to: "/dashboard", k: "btc chart market live price trade" },
  { label: "Markets — all coins", to: "/markets", k: "markets coins eth bnb sol xrp doge ada shib pepe ltc trx avax link dot matic price" },
  { label: "FAQ & guides", to: "/learning", k: "faq help questions guide learn" },
  { label: "Deposit USDT", to: "/deposit", k: "deposit add funds" },
  { label: "Withdraw USDT", to: "/withdraw", k: "withdraw cash out" },
  { label: "Wallet & transactions", to: "/wallet", k: "wallet balance transactions" },
  { label: "Trade history", to: "/history", k: "history win loss trades" },
  { label: "Profile, photo & referral", to: "/profile", k: "profile settings photo name referral code invite install app" },
] as const;

function SearchPanel({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState("");
  const nav = useNavigate();
  const t = q.trim().toLowerCase();
  const res = SEARCH_ITEMS.filter((i) => !t || (i.label + " " + i.k).toLowerCase().includes(t));
  return (
    <div className="fixed inset-x-0 bottom-0 top-16 z-[9999] flex justify-center bg-background/95 px-4 pt-4" onClick={onClose}>
      <div className="glass-card fade-up h-fit w-full max-w-sm p-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2">
          <Search className="h-5 w-5 text-primary" />
          <input autoFocus className="field py-2" placeholder="Search help, markets, settings…" value={q} onChange={(e) => setQ(e.target.value)} />
          <button aria-label="Close" onClick={onClose}><X className="h-5 w-5" /></button>
        </div>
        <ul className="mt-3 max-h-80 overflow-auto">
          {res.map((i) => (
            <li key={i.label}><button className="w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-muted" onClick={() => { onClose(); nav({ to: i.to }); }}>{i.label}</button></li>
          ))}
          {!res.length && <li className="p-3 text-center text-sm text-muted-foreground">No results</li>}
        </ul>
      </div>
    </div>
  );
}

function useNotifications() {
  const uid = useUserId();
  return useQuery({
    queryKey: ["notifications", uid],
    enabled: !!uid,
    refetchInterval: 30_000,
    queryFn: async () => {
      const { data } = await supabase.from("notifications").select("*")
        .order("created_at", { ascending: false }).limit(30);
      return data ?? [];
    },
  });
}

function NotificationsPanel({ onClose, items }: { onClose: () => void; items: { id: string; title: string; message: string; type: string; created_at: string }[] }) {
  return (
    <div className="fixed inset-x-0 bottom-0 top-16 z-[9999] flex justify-center bg-background/95 px-4 pt-4" onClick={onClose}>
      <div className="glass-card fade-up h-fit max-h-[75vh] w-full max-w-sm overflow-y-auto p-4" onClick={(e) => e.stopPropagation()}>
        <div className="mb-2 flex items-center justify-between"><h3 className="font-bold">Notifications</h3><button aria-label="Close" onClick={onClose}><X className="h-5 w-5" /></button></div>
        <ul className="max-h-96 divide-y divide-border overflow-auto">
          {items.map((n) => (
            <li key={n.id} className="py-3">
              <div className="flex items-center gap-2 text-sm font-semibold">{n.title}<span className="chip chip-wait">{n.type === "broadcast" ? "All" : n.type === "bonus" ? "Bonus" : "You"}</span></div>
              <p className="text-sm text-muted-foreground">{n.message}</p>
              <p className="text-[11px] text-muted-foreground">{new Date(n.created_at).toLocaleString()}</p>
            </li>
          ))}
          {!items.length && <li className="p-4 text-center text-sm text-muted-foreground">No notifications yet</li>}
        </ul>
      </div>
    </div>
  );
}

export function InstallButton({ compact = false }: { compact?: boolean }) {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const update = () => setShow(canInstall() && !isStandalone());
    update();
    const off = onInstallChange(update);
    return () => { off(); };
  }, []);
  if (!show) return null;
  const install = async () => {
    const r = await promptInstall();
    if (r === "accepted") { toast.success("Installed"); setShow(false); }
  };
  if (compact) return <button aria-label="Install app" onClick={install}><Download className="h-6 w-6 text-primary" /></button>;
  return <button className="btn-outline w-full py-2.5 text-sm" onClick={install}><Download className="h-4 w-4" /> Install App</button>;
}

export function TopBar({ deposit = false }: { deposit?: boolean } = {}) {
  const name = useAppName();
  const { data: notes = [] } = useNotifications();
  const [panel, setPanel] = useState<"search" | "bell" | null>(null);
  const seenKey = "at_notes_seen";
  const seen = typeof window !== "undefined" ? localStorage.getItem(seenKey) ?? "" : "";
  const unread = notes.filter((n) => n.created_at > seen).length;
  return (
    <header className="sticky top-0 z-[10000] -mx-4 flex w-[calc(100%+2rem)] items-center justify-between gap-1 bg-background px-4 pb-4 pt-5">
      <Link to="/dashboard" className="flex min-w-0 flex-1 items-center gap-2 max-[360px]:gap-1"><Logo size={36} className="shrink-0 max-[360px]:!h-7 max-[360px]:!w-7" /><span className="min-w-0 truncate whitespace-nowrap font-display text-xl font-bold text-primary max-[360px]:text-lg">{name}</span></Link>
      <div className="flex shrink-0 items-center gap-2 pr-1 max-[360px]:gap-1">
        <InstallButton compact />
        {deposit && <Link to="/deposit" className="btn-outline flex h-[38px] w-[120px] items-center justify-center gap-1 px-0 py-0 text-sm">Deposit</Link>}
        <Link to="/swap" search={{}} className="chip chip-wait px-3 py-1 text-xs font-semibold max-[360px]:px-2">Swap</Link>
        <Button variant="ghost" size="icon" className="h-6 w-6 text-primary [&_svg]:size-6" aria-label="Search" onClick={() => setPanel("search")}><Search /></Button>
        <Button variant="ghost" size="icon" aria-label="Notifications" className="relative h-6 w-6 text-primary [&_svg]:size-6" onClick={() => { setPanel("bell"); if (notes[0]) localStorage.setItem(seenKey, notes[0].created_at); }}>
          <Bell className="h-6 w-6 text-primary" />
          {unread > 0 && <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">{unread}</span>}
        </Button>
      </div>
      {panel === "search" && createPortal(<SearchPanel onClose={() => setPanel(null)} />, document.body)}
      {panel === "bell" && createPortal(<NotificationsPanel items={notes} onClose={() => setPanel(null)} />, document.body)}
    </header>
  );
}

const NAV = [
  { to: "/dashboard", label: "Home", icon: House },
  { to: "/markets", label: "Markets", icon: CandlestickChart },
  { to: "/wallet", label: "Wallet", icon: Wallet },
  { to: "/history", label: "History", icon: HistoryIcon },
  { to: "/profile", label: "Profile", icon: UserRound },
] as const;

export function BottomNav() {
  const { pathname } = useLocation();
  return (
    <nav className="bottom-nav">
      <ul className="grid grid-cols-5">
        {NAV.map(({ to, label, icon: Icon }) => {
          const active = pathname.startsWith(to);
          return (
            <li key={to}>
              <Link to={to} className={`flex flex-col items-center gap-1 rounded-xl py-1.5 text-[11px] font-medium transition ${active ? "bg-primary text-primary-foreground" : "text-primary/70"}`}>
                <Icon className="h-6 w-6" strokeWidth={active ? 2.2 : 1.8} />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function useProfileAvatar() {
  const { data } = useProfile();
  return data;
}
