import { memo, useEffect, useState } from "react";
import { profileGreeting } from "@/lib/greeting";

export const ProfileGreeting = memo(function ProfileGreeting({ trading }: { trading: boolean }) {
  const [hour, setHour] = useState<number | null>(null);
  useEffect(() => {
    const update = () => setHour(new Date().getHours());
    update();
    const timer = setInterval(update, 30_000);
    window.addEventListener("focus", update);
    return () => { clearInterval(timer); window.removeEventListener("focus", update); };
  }, []);
  return <div className="text-xs text-muted-foreground" aria-live="polite">{hour === null ? "\u00a0" : profileGreeting(hour, trading)}</div>;
});