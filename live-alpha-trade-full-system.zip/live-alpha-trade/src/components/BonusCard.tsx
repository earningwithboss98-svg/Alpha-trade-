import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Gift } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { errMsg, fmtTimer, money, useUserId } from "@/lib/app-data";

export function BonusCard() {
  const uid = useUserId();
  const qc = useQueryClient();
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const iv = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(iv); }, []);
  const { data: b } = useQuery({
    queryKey: ["bonus", uid],
    enabled: !!uid,
    refetchInterval: 30_000,
    queryFn: async () => {
      const { data } = await supabase.from("bonuses").select("*").eq("user_id", uid!).eq("status", "pending")
        .gt("expires_at", new Date().toISOString()).order("created_at", { ascending: false }).limit(1);
      return data?.[0] ?? null;
    },
  });
  if (!b) return null;
  const left = Math.max(0, Math.floor((new Date(b.expires_at).getTime() - now) / 1000));
  if (left <= 0) return null;
  const claim = async () => {
    const { error } = await supabase.rpc("claim_bonus", { _id: b.id });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(`${money(b.amount)} bonus added to your wallet`);
    qc.invalidateQueries();
  };
  return (
    <div className="mt-4 flex flex-wrap items-center gap-2">
      <div className="bonus-strip flex min-w-0 flex-1 items-center gap-3 rounded-xl px-3 py-2">
        <Gift className="h-7 w-7 shrink-0" />
        <div className="min-w-0">
          <div className="font-bold">+{money(b.amount)} BONUS</div>
          <div className="text-xs font-medium">{b.reason} credited · Expires in 24 hours</div>
          <div className="text-[11px] font-bold tabular-nums">{fmtTimer(left)}</div>
        </div>
      </div>
      <button className="btn-primary px-4 py-2 max-[400px]:w-full" onClick={claim}>Claim</button>
    </div>
  );
}
