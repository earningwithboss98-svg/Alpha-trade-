import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { createChart, type IChartApi, type ISeriesApi, type IPriceLine, type UTCTimestamp } from "lightweight-charts";
import { marketKlines, marketPrice } from "@/lib/market.functions";

type Candle = { time: UTCTimestamp; open: number; high: number; low: number; close: number };
export type LiveChartHandle = {
  reload: () => void;
  zoom: (dir: 1 | -1) => void;
  price: () => number | null;
  setEntry: (price: number | null, side?: "up" | "down") => void;
};

const UP = "#00e676", DOWN = "#ff3b30";
const REST_HOSTS = ["https://data-api.binance.vision", "https://api.binance.com", "https://api1.binance.com"];
const WS_HOSTS = ["wss://stream.binance.com:9443/ws/btcusdt@trade", "wss://data-stream.binance.vision/ws/btcusdt@trade"];

export const LiveChart = forwardRef<LiveChartHandle, { height: number | string; onPrice?: (p: number, chg: number) => void; onStatus?: (s: string) => void }>(
  function LiveChart({ height, onPrice, onStatus }, ref) {
    const box = useRef<HTMLDivElement>(null);
    const chart = useRef<IChartApi | null>(null);
    const series = useRef<ISeriesApi<"Candlestick"> | null>(null);
    const last = useRef<Candle | null>(null);
    const target = useRef<number | null>(null);
    const anim = useRef<{ from: number; to: number; start: number } | null>(null);
    const ws = useRef<WebSocket | null>(null);
    const entry = useRef<IPriceLine | null>(null);
    const dayOpen = useRef<number | null>(null);
    const [gen, setGen] = useState(0);
    const cb = useRef({ onPrice, onStatus });
    cb.current = { onPrice, onStatus };

    // Create chart (keyed on gen so React double-mount keeps data & series in sync)
    useEffect(() => {
      if (!box.current) return;
      const c = createChart(box.current, {
        autoSize: true,
        layout: { background: { color: "transparent" }, textColor: "#a9a6c9", fontFamily: "Inter, sans-serif" },
        grid: { vertLines: { color: "rgba(139,92,246,0.07)" }, horzLines: { color: "rgba(139,92,246,0.07)" } },
        rightPriceScale: { borderColor: "rgba(139,92,246,0.2)" },
        timeScale: { borderColor: "rgba(139,92,246,0.2)", timeVisible: true, secondsVisible: false, rightOffset: 4, barSpacing: 7 },
        crosshair: { mode: 1 },
        localization: { locale: "en-US" },
        handleScale: { pinch: true, mouseWheel: true, axisPressedMouseMove: true },
        handleScroll: true,
      });
      series.current = c.addCandlestickSeries({
        upColor: UP, downColor: DOWN, borderUpColor: UP, borderDownColor: DOWN, wickUpColor: UP, wickDownColor: DOWN,
        priceLineColor: "#00e5ff",
      });
      chart.current = c;
      let raf = 0;
      const tick = (now: number) => {
        const a = anim.current;
        if (a && last.current && series.current) {
          const t = Math.min(1, (now - a.start) / 150);
          const e = 1 - Math.pow(1 - t, 3);
          const v = a.from + (a.to - a.from) * e;
          const cd = last.current;
          cd.close = v; cd.high = Math.max(cd.high, v); cd.low = Math.min(cd.low, v);
          series.current.update({ ...cd });
          if (t >= 1) anim.current = null;
        }
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
      return () => { cancelAnimationFrame(raf); c.remove(); chart.current = null; series.current = null; last.current = null; };
    }, [gen]);

    // Load data + live stream (multi-host WS with server-side REST/polling fallback)
    useEffect(() => {
      let alive = true;
      let retry: ReturnType<typeof setTimeout> | undefined;
      let poll: ReturnType<typeof setInterval> | null = null;
      let beat: ReturnType<typeof setInterval> | null = null;
      let wsUp = false;
      let wsIdx = 0;
      let backoff = 1000;
      let lastMsg = 0;
      let lastEmit = 0;
      let pending: number | null = null;
      let emitTimer: ReturnType<typeof setTimeout> | null = null;

      const emit = (p: number) => {
        const base = dayOpen.current ?? p;
        cb.current.onPrice?.(p, ((p - base) / base) * 100);
        lastEmit = performance.now();
      };
      // Chart updates on every tick; React price text updates at most every 150ms (keeps UI smooth during bets)
      const report = (p: number) => {
        pending = p;
        if (emitTimer) return;
        const wait = Math.max(0, 150 - (performance.now() - lastEmit));
        emitTimer = setTimeout(() => { emitTimer = null; if (alive && pending != null) emit(pending); }, wait);
      };

      const applyPrice = (p: number, T: number) => {
        if (!alive || !last.current || !p) return;
        const bucket = (Math.floor(T / 60000) * 60) as UTCTimestamp;
        if (bucket > last.current.time) {
          const prev = last.current.close;
          last.current = { time: bucket, open: prev, high: Math.max(prev, p), low: Math.min(prev, p), close: prev };
          series.current?.update({ ...last.current });
        }
        if (target.current !== p) {
          anim.current = { from: last.current.close, to: p, start: performance.now() };
          target.current = p;
        }
        report(p);
      };

      const startPolling = () => {
        if (poll || !alive) return;
        poll = setInterval(async () => {
          if (wsUp) return; // live stream is feeding the chart
          try {
            const { price } = await marketPrice();
            if (!alive || wsUp) return;
            cb.current.onStatus?.("Live");
            applyPrice(price, Date.now());
          } catch { cb.current.onStatus?.("Connecting"); }
        }, 1000);
      };

      const load = async () => {
        if (!series.current) return;
        cb.current.onStatus?.("Connecting");
        let data: Candle[] | null = null;
        for (const h of REST_HOSTS) {
          try {
            const r = await fetch(`${h}/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=100`);
            if (!r.ok) continue;
            const rows: string[][] = await r.json();
            data = rows.map((k) => ({
              time: Math.floor(Number(k[0]) / 1000) as UTCTimestamp, open: Number(k[1]), high: Number(k[2]), low: Number(k[3]), close: Number(k[4]),
            }));
            break;
          } catch { /* try next host */ }
        }
        if (!data) {
          try {
            const { candles } = await marketKlines();
            data = (candles as Candle[]).map((c) => ({ ...c, time: c.time as UTCTimestamp }));
          } catch { data = null; }
        }
        if (!alive || !data?.length || !series.current) { cb.current.onStatus?.("Connecting"); return; }
        series.current.setData(data);
        const lc = data[data.length - 1];
        if (!lc) return;
        last.current = { ...lc };
        target.current = lc.close;
        dayOpen.current = data[0]?.open ?? lc.open;
        chart.current?.timeScale().scrollToRealTime();
        emit(lc.close);
      };

      const connect = () => {
        if (!alive) return;
        const s = new WebSocket(WS_HOSTS[wsIdx % WS_HOSTS.length]!);
        ws.current = s;
        let opened = false;
        const watchdog = setTimeout(() => { if (!opened) s.close(); }, 3000);
        s.onopen = () => {
          opened = true; wsUp = true; backoff = 1000; lastMsg = Date.now(); clearTimeout(watchdog);
          if (alive) cb.current.onStatus?.("Live");
        };
        s.onmessage = (ev) => {
          lastMsg = Date.now();
          try {
            const m = JSON.parse(ev.data) as { p?: string; T?: number };
            if (m.p) applyPrice(Number(m.p), m.T ?? Date.now());
          } catch { /* ignore non-trade frames */ }
        };
        s.onclose = () => {
          clearTimeout(watchdog);
          wsUp = false;
          if (!alive) return;
          wsIdx += 1;
          cb.current.onStatus?.("Connecting");
          retry = setTimeout(connect, backoff);
          backoff = Math.min(backoff * 2, 16000);
        };
        s.onerror = () => s.close();
      };

      // Heartbeat every 20s: if stream went silent, force a reconnect
      beat = setInterval(() => {
        const s = ws.current;
        if (wsUp && s && Date.now() - lastMsg > 20000) s.close();
      }, 20000);

      load().then(() => {
        if (!alive) return;
        connect();
        startPolling();
      });
      return () => {
        alive = false;
        if (retry) clearTimeout(retry);
        if (poll) clearInterval(poll);
        if (beat) clearInterval(beat);
        if (emitTimer) clearTimeout(emitTimer);
        ws.current?.close();
      };
    }, [gen]);

    useImperativeHandle(ref, () => ({
      reload: () => setGen((g) => g + 1),
      zoom: (dir) => {
        const ts = chart.current?.timeScale();
        if (!ts) return;
        const cur = ts.options().barSpacing;
        ts.applyOptions({ barSpacing: Math.max(2, Math.min(40, cur * (dir > 0 ? 1.3 : 0.77))) });
      },
      price: () => target.current,
      setEntry: (price, side) => {
        if (entry.current && series.current) { series.current.removePriceLine(entry.current); entry.current = null; }
        if (price != null && series.current) {
          entry.current = series.current.createPriceLine({
            price, color: side === "up" ? UP : DOWN, lineWidth: 2, lineStyle: 2, axisLabelVisible: true, title: side === "up" ? "UP" : "DOWN",
          });
        }
      },
    }));

    return <div ref={box} style={{ height, width: "100%", touchAction: "none" }} />;
  },
);
