import { useEffect, useState } from "react";
import confetti from "canvas-confetti";
import { QRCodeSVG } from "qrcode.react";
import { Copy, X } from "lucide-react";
import { toast } from "sonner";
import { Logo } from "./brand";
import { money } from "@/lib/app-data";

function burst(colors: string[]) {
  const end = Date.now() + 900;
  (function frame() {
    confetti({ particleCount: 6, angle: 60, spread: 70, origin: { x: 0 }, colors, zIndex: 10001 });
    confetti({ particleCount: 6, angle: 120, spread: 70, origin: { x: 1 }, colors, zIndex: 10001 });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();
}

export function WelcomeModal({ kind, onClose }: { kind: "new" | "back"; onClose: () => void }) {
  useEffect(() => { burst(["#8b5cf6", "#00e5ff", "#ffffff"]); }, []);
  return (
    <div className="modal-backdrop" role="dialog" aria-modal>
      <div className="modal-card animate-in zoom-in-90 fade-in">
        <Logo size={84} className="mx-auto mb-4" />
        {kind === "new" ? (
          <>
            <h2 className="text-2xl font-bold">Welcome to Live Trading!</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Live BTC/USDT real Binance market, small investment, real profit, no big investment needed. Trade smart, earn real!
            </p>
          </>
        ) : (
          <>
            <h2 className="text-2xl font-bold">Welcome Back! 🎉</h2>
            <p className="mt-3 text-sm text-muted-foreground">Live market waiting for you</p>
          </>
        )}
        <button className="btn-primary mt-5 w-full" onClick={onClose}>Start Trading</button>
      </div>
    </div>
  );
}

export function ResultModal({ result, onClose }: {
  result: { status: string; amount: number; profit: number; payout: number }; onClose: () => void;
}) {
  const win = result.status === "win";
  useEffect(() => { if (win) burst(["#00e676", "#00e5ff", "#ffffff"]); }, [win]);
  return (
    <div className="modal-backdrop" role="dialog" aria-modal>
      <div className={`modal-card animate-in zoom-in-90 fade-in ${win ? "modal-win" : ""}`}>
        {win ? (
          <>
            <div className="text-6xl">🏆</div>
            <h2 className="mt-2 text-3xl font-extrabold text-up">You Won! 🎉🎉</h2>
            <div className="mt-4 space-y-1 text-sm">
              <p>Invested: <b>{money(result.amount)}</b></p>
              <p>Profit: <b className="text-up">{money(result.profit)}</b></p>
              <p>Total Returned: <b className="text-up">{money(result.payout)}</b> added</p>
            </div>
            <button className="btn-up mt-6 w-full" onClick={onClose}>Continue</button>
          </>
        ) : result.status === "draw" ? (
          <>
            <div className="text-5xl">🤝</div>
            <h2 className="mt-2 text-2xl font-bold">Price unchanged</h2>
            <p className="mt-3 text-sm text-muted-foreground">Your {money(result.amount)} was returned to your balance.</p>
            <button className="btn-primary mt-6 w-full" onClick={onClose}>Trade again</button>
          </>
        ) : (
          <>
            <div className="text-5xl">💪</div>
            <h2 className="mt-2 text-2xl font-bold">Don't Give Up! 💪</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Your {money(result.amount)} trade was close! Try again - Next win is yours! Every expert was once a beginner.
            </p>
            <button className="btn-primary mt-6 w-full" onClick={onClose}>Try Again</button>
          </>
        )}
      </div>
    </div>
  );
}

export function QrModal({ address, onClose }: { address: string; onClose: () => void }) {
  return (
    <div className="modal-backdrop" role="dialog" aria-modal onClick={onClose}>
      <div className="modal-card relative" onClick={(e) => e.stopPropagation()}>
        <button className="absolute right-4 top-4 text-muted-foreground" onClick={onClose} aria-label="Close"><X /></button>
        <h3 className="text-lg font-bold">USDT · BEP20 Address</h3>
        {address ? (
          <>
            <div className="mx-auto mt-4 w-fit rounded-2xl bg-foreground p-3">
              <QRCodeSVG value={address} size={190} />
            </div>
            <p className="mt-4 break-all rounded-xl bg-muted p-3 font-mono text-xs">{address}</p>
            <CopyButton text={address} className="btn-primary mt-3 w-full" label="Copy Address" />
            <p className="mt-3 text-[11px] text-muted-foreground">Send only USDT on BNB Smart Chain (BEP20).</p>
          </>
        ) : (
          <p className="mt-4 text-sm text-muted-foreground">Deposit address is being updated. Please try again shortly.</p>
        )}
      </div>
    </div>
  );
}

export function CopyButton({ text, label = "Copy", className = "btn-outline" }: { text: string; label?: string; className?: string }) {
  const [done, setDone] = useState(false);
  return (
    <button type="button" className={className} onClick={async () => {
      await navigator.clipboard.writeText(text); setDone(true); toast.success(label === "Copy Address" ? "Address Copied!" : "Copied"); setTimeout(() => setDone(false), 1500);
    }}>
      <Copy className="h-4 w-4" /> {done ? "Copied" : label}
    </button>
  );
}
