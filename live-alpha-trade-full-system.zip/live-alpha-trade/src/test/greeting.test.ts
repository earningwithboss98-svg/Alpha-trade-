import { describe, expect, it } from "vitest";
import { profileGreeting, timeGreeting } from "@/lib/greeting";

describe("Live greeting time boundaries", () => {
  it("uses morning from 5am until noon", () => {
    expect(timeGreeting(5)).toBe("Good Morning");
    expect(timeGreeting(11)).toBe("Good Morning");
    expect(timeGreeting(12)).not.toBe("Good Morning");
  });
  it("uses afternoon from noon until 5pm", () => {
    expect(timeGreeting(12)).toBe("Good Afternoon");
    expect(timeGreeting(16)).toBe("Good Afternoon");
    expect(timeGreeting(17)).not.toBe("Good Afternoon");
  });
  it("uses evening from 5pm until 9pm", () => {
    expect(timeGreeting(17)).toBe("Good Evening");
    expect(timeGreeting(20)).toBe("Good Evening");
    expect(timeGreeting(21)).not.toBe("Good Evening");
  });
  it("uses night from 9pm until 5am", () => {
    expect(timeGreeting(21)).toBe("Good Night");
    expect(timeGreeting(0)).toBe("Good Night");
    expect(timeGreeting(4)).toBe("Good Night");
    expect(timeGreeting(5)).not.toBe("Good Night");
  });
  it("reports trading only when an active trade exists", () => {
    expect(profileGreeting(8, true)).toBe("Good Morning - Good trading");
    expect(profileGreeting(8, false)).toBe("Good Morning");
  });
});