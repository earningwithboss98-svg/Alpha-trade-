import { createFileRoute } from "@tanstack/react-router";
import { readPublicSettings } from "@/lib/settings.server";

export const Route = createFileRoute("/manifest.webmanifest")({
  server: {
    handlers: {
      GET: async () => {
        const s = await readPublicSettings();
        const name = s?.app_name || "Alpha Trade";
        const v = s?.updated_at ? new Date(s.updated_at).getTime() : 1;
        const body = {
          name, short_name: name.replace(/\s+/g, ""), start_url: "/", scope: "/", display: "standalone",
          theme_color: "#0a0a0a", background_color: "#0a0a0a",
          icons: [
            { src: `/api/public/icon/192?v=${v}`, sizes: "192x192", type: "image/png", purpose: "any maskable" },
            { src: `/api/public/icon/512?v=${v}`, sizes: "512x512", type: "image/png", purpose: "any maskable" },
          ],
        };
        return new Response(JSON.stringify(body), {
          headers: { "content-type": "application/manifest+json", "cache-control": "public, max-age=300" },
        });
      },
    },
  },
});
