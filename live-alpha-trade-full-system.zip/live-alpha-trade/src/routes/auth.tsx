import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Logo } from "@/components/brand";
import { useAppName } from "@/lib/app-data";
import { LoaderCircle } from "lucide-react";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { mode?: "register"; blocked?: number } => ({
    ...(s["mode"] === "register" ? { mode: "register" as const } : {}),
    ...(s["blocked"] ? { blocked: 1 } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Sign in — Alpha Trade" },
      { name: "description", content: "Sign in or create your Alpha Trade account to trade BTC/USDT live." },
      { property: "og:title", content: "Sign in — Alpha Trade" },
      { property: "og:description", content: "Sign in or create your Alpha Trade account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

const schema = z.object({
  email: z.string().trim().email("Enter a valid email").max(255),
  password: z.string().min(8, "Password must be at least 8 characters").max(72),
  name: z.string().trim().max(60).optional(),
});

function AuthPage() {
  const search = Route.useSearch();
  const nav = useNavigate();
  const appName = useAppName();
  const [mode, setMode] = useState<"login" | "register">(search.mode === "register" ? "register" : "login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const [refCode, setRefCode] = useState("");
  useEffect(() => { setRefCode(localStorage.getItem("at_ref") || ""); }, []);

  useEffect(() => {
    if (search.blocked) toast.error("Your account is blocked. Please contact support.");
    supabase.auth.getSession().then(({ data }) => { if (data.session) nav({ to: "/dashboard", replace: true }); });
    const { data } = supabase.auth.onAuthStateChange((e, s) => { if (e === "SIGNED_IN" && s) nav({ to: "/dashboard", replace: true }); });
    return () => { data.subscription.unsubscribe(); };
  }, [nav, search.blocked]);

  const submit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (busy) return;
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error(parsed.error.issues[0]?.message ?? "Invalid input"); return; }
    setBusy(true);
    try {
      if (mode === "register") {
        const ref = (refCode || localStorage.getItem("at_ref") || "").trim().toUpperCase();
        if (ref) {
          const { data: ok } = await supabase.rpc("referral_exists", { _code: ref });
          if (!ok) { toast.error("Invalid referral code"); localStorage.removeItem("at_ref"); return; }
        }
        const { data, error } = await supabase.auth.signUp({
          email: parsed.data.email, password: parsed.data.password,
          options: { emailRedirectTo: window.location.origin + "/dashboard", data: { name: parsed.data.name || undefined, ref } },
        });
        if (error) throw error;
        if (!data.session) setSent(true);
      } else {
        sessionStorage.setItem("at_welcome", "back");
        const { error } = await supabase.auth.signInWithPassword({ email: parsed.data.email, password: parsed.data.password });
        if (error) throw error;
      }
    } catch (err) {
      toast.error((err as Error).message);
    } finally { setBusy(false); }
  };

  const google = async () => {
    sessionStorage.setItem("at_welcome", "back");
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (r.error) toast.error(r.error.message || "Google sign-in failed");
  };

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-5 py-10">
      <div className="mb-8 text-center">
        <Logo size={96} className="mx-auto" />
        <h1 className="mt-4 text-3xl font-bold">{appName}</h1>
        <p className="mt-1 text-sm text-muted-foreground">Live BTC/USDT trading on real Binance prices</p>
      </div>

      {sent ? (
        <div className="glass-card p-6 text-center">
          <h2 className="text-xl font-bold">Check your email</h2>
          <p className="mt-2 text-sm text-muted-foreground">We sent a confirmation link to <b>{form.email}</b>. Open it to activate your account.</p>
          <button className="btn-outline mt-5 w-full" onClick={() => { setSent(false); setMode("login"); }}>Back to sign in</button>
        </div>
      ) : (
        <div className="glass-card p-6">
          <div className="mb-5 grid grid-cols-2 rounded-xl bg-muted p-1 text-sm font-semibold">
            {(["login", "register"] as const).map((m) => (
              <button key={m} onClick={() => setMode(m)}
                className={`rounded-lg py-2 ${mode === m ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>
                {m === "login" ? "Sign in" : "Register"}
              </button>
            ))}
          </div>
          <form onSubmit={submit} className="space-y-4">
            {mode === "register" && (<>
              <div><label className="label">Name</label>
                <input className="field" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" /></div>
                <div><label className="label">Referral Code (optional)</label>
                <input className="field uppercase" maxLength={6} value={refCode} onChange={(e) => setRefCode(e.target.value)} placeholder="ABC123" /></div>
            </>)}
            <div><label className="label">Email</label>
              <input className="field" type="email" autoComplete="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@email.com" /></div>
            <div><label className="label">Password</label>
              <input className="field" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="At least 8 characters" /></div>
            <button className="btn-primary w-full" disabled={busy}>{busy && <LoaderCircle className="h-4 w-4 animate-spin" aria-hidden />}{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
          </form>
          <div className="my-4 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />or<span className="h-px flex-1 bg-border" /></div>
          <button className="btn-outline w-full" onClick={google}>Continue with Google</button>
        </div>
      )}
    </main>
  );
}
