import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { Activity, ArrowDownToLine, ArrowUpFromLine, Gift, ShieldCheck, Timer } from "lucide-react";
import { Logo } from "@/components/brand";
import { useAppName } from "@/lib/app-data";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Alpha Trade — Trade BTC/USDT Live, 15s to 5 Minutes" },
      { name: "description", content: "Trade BTC/USDT on live Binance prices with timers from 15 seconds to 5 minutes. USDT BEP20 deposits, fast withdrawals, referral bonus." },
      { property: "og:title", content: "Alpha Trade — Trade BTC/USDT Live" },
      { property: "og:description", content: "Live Binance BTC/USDT price, small investment, timers from 15s to 5 minutes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const BENEFITS = [
  { icon: Activity, t: "Live Binance Price", d: "Real BTC/USDT candles streamed tick by tick." },
  { icon: ArrowDownToLine, t: "Instant Deposit BEP20", d: "Send USDT on BNB Smart Chain, upload proof, done." },
  { icon: ArrowUpFromLine, t: "Fast Withdraw", d: "Request to your own BEP20 address during working hours." },
  { icon: Gift, t: "Referral Bonus", d: "Share your short link and invite friends." },
  { icon: ShieldCheck, t: "Secure", d: "Encrypted accounts and server-side settlement." },
];

const FAQ = [
  ["How are trades decided?", "At the end of your timer, the live Binance BTC/USDT price is compared with your entry price. Up wins if price is higher, Down wins if price is lower."],
  ["What is the minimum to start?", "You can start with a small amount. Limits are shown on the deposit and trade screens."],
  ["Which network do you accept?", "USDT on BNB Smart Chain (BEP20) only."],
  ["How long do withdrawals take?", "Withdrawals are reviewed during the working hours shown on the withdraw page."],
];

function Landing() {
  const name = useAppName();
  const nav = useNavigate();
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { if (data.session) nav({ to: "/dashboard", replace: true }); });
  }, [nav]);

  return (
    <main className="mx-auto max-w-5xl px-5 pb-16">
      <header className="flex items-center justify-between py-5">
        <div className="flex items-center gap-2"><Logo size={44} /><span className="text-lg font-bold">{name}</span></div>
        <Link to="/auth" search={{}} className="btn-outline px-4 py-2 text-sm">Sign in</Link>
      </header>

      <section className="grid items-center gap-10 py-10 md:grid-cols-2 md:py-20">
        <div>
          <span className="chip chip-wait"><span className="live-dot mr-2" />Live market</span>
          <h1 className="mt-4 text-4xl font-bold leading-tight md:text-6xl">Trade BTC/USDT Live — <span className="text-primary">15s to 5 Minutes</span></h1>
          <p className="mt-4 text-lg text-muted-foreground">Real Binance prices, small investment, simple Up or Down. Start in minutes.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/auth" search={{ mode: "register" }} className="btn-primary px-6">Start Trading</Link>
            <Link to="/auth" search={{}} className="btn-outline px-6">I have an account</Link>
          </div>
        </div>
        <div className="glass-card flex items-center justify-center p-10">
          <Logo size={240} />
        </div>
      </section>

      <section className="py-10">
        <h2 className="text-2xl font-bold">Why {name}</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {BENEFITS.map(({ icon: I, t, d }) => (
            <div key={t} className="glass-card p-5">
              <I className="h-7 w-7 text-primary" /><h3 className="mt-3 font-semibold">{t}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-10">
        <h2 className="text-2xl font-bold">How it works</h2>
        <ol className="mt-6 grid gap-4 md:grid-cols-3">
          {[["Deposit USDT", "Send USDT (BEP20) and upload your payment screenshot."], ["Pick a timer", "Choose 15s to 5 minutes and your investment."], ["Buy or Sell", "Predict Up or Down. Wins are credited instantly."]].map(([t, d], i) => (
            <li key={t} className="glass-card p-5">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary font-bold text-primary-foreground">{i + 1}</div>
              <h3 className="mt-3 font-semibold">{t}</h3><p className="mt-1 text-sm text-muted-foreground">{d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="py-10">
        <h2 className="flex items-center gap-2 text-2xl font-bold"><Timer className="text-primary" /> FAQ</h2>
        <div className="mt-6 space-y-3">
          {FAQ.map(([q, a]) => (
            <details key={q} className="glass-card p-5"><summary className="cursor-pointer font-semibold">{q}</summary><p className="mt-2 text-sm text-muted-foreground">{a}</p></details>
          ))}
        </div>
      </section>
      <footer className="mt-10 text-center text-xs text-muted-foreground">© {new Date().getFullYear()} {name}</footer>
    </main>
  );
}
