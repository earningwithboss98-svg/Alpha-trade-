import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ context }) => {
    const { data } = await supabase.auth.getSession();
    const user = data.session?.user;
    if (!user) throw redirect({ to: "/auth", search: {} });
    const p = await context.queryClient.ensureQueryData({
      queryKey: ["route-access", user.id],
      staleTime: 30_000,
      queryFn: async () => {
        const { data: profile, error } = await supabase.from("profiles").select("blocked").eq("id", user.id).maybeSingle();
        if (error) throw error;
        return profile;
      },
    });
    if (p?.blocked) {
      await supabase.auth.signOut();
      throw redirect({ to: "/auth", search: { blocked: 1 } as never });
    }
  },
  component: () => <Outlet />,
});
