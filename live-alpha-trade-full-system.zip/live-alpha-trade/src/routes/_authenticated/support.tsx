import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Headset, Loader2, Plus, Send, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { BottomNav } from "@/components/brand";
import { errMsg, useUserId } from "@/lib/app-data";

export const Route = createFileRoute("/_authenticated/support")({
  head: () => ({
    meta: [
      { title: "Customer Support — Alpha Trade" },
      { name: "description", content: "Chat with Alpha Trade support about deposits, withdrawals and your account." },
      { property: "og:title", content: "Customer Support — Alpha Trade" },
      { property: "og:description", content: "Chat with Alpha Trade support." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Support,
});

const CHIPS = ["Deposit", "Withdraw", "Password", "Other"] as const;

type Msg = { id: string; sender: string; body: string; image_path: string | null; created_at: string };

function ChatImage({ path }: { path: string }) {
  const { data } = useQuery({
    queryKey: ["support-img", path],
    staleTime: 240_000,
    queryFn: async () => (await supabase.storage.from("support-images").createSignedUrl(path, 300)).data?.signedUrl ?? null,
  });
  return data ? <img src={data} alt="Attachment" loading="lazy" className="mt-1 max-h-48 rounded-lg" /> : <div className="mt-1 h-24 w-32 animate-pulse rounded-lg bg-muted" />;
}

function Support() {
  const uid = useUserId();
  const qc = useQueryClient();
  const [cat, setCat] = useState<(typeof CHIPS)[number]>("Deposit");
  const [text, setText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  const { data: msgs = [], isLoading } = useQuery({
    queryKey: ["support-chat", uid],
    enabled: !!uid,
    refetchInterval: 15_000,
    queryFn: async () => {
      const since = new Date(Date.now() - 24 * 3600_000).toISOString();
      const { data } = await supabase.from("support_messages").select("id,sender,body,image_path,created_at")
        .gt("created_at", since).order("created_at", { ascending: true }).limit(50);
      return (data ?? []) as Msg[];
    },
  });
  // Conversation expires 24h after its last message.
  const visible = msgs.length && Date.now() - new Date(msgs[msgs.length - 1]!.created_at).getTime() > 24 * 3600_000 ? [] : msgs;

  useEffect(() => { end.current?.scrollIntoView({ block: "end" }); }, [visible.length]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uid || busy) return;
    const body = text.trim();
    if (!body && !file) return;
    setBusy(true);
    try {
      let image_path: string | null = null;
      if (file) {
        if (file.size > 5 * 1024 * 1024) throw new Error("Image must be under 5 MB");
        image_path = `${uid}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
        const { error } = await supabase.storage.from("support-images").upload(image_path, file);
        if (error) throw error;
      }
      const { error } = await supabase.from("support_messages").insert({ user_id: uid, sender: "user", body: body.slice(0, 2000), image_path, category: cat });
      if (error) throw error;
      setText(""); setFile(null);
      await qc.invalidateQueries({ queryKey: ["support-chat", uid] });
    } catch (err) { toast.error(errMsg(err)); } finally { setBusy(false); }
  };

  return (
    <div className="page pb-44">
      <header className="flex items-center gap-3 pb-3 pt-5">
        <div className="flex h-10 w-10 items-center justify-center rounded-full border border-primary/40 bg-primary/15 text-primary"><Headset className="h-5 w-5" /></div>
        <div><h1 className="text-xl font-bold">Customer Support</h1><p className="text-xs text-muted-foreground">Chats are kept for 24 hours</p></div>
      </header>
      <div className="flex gap-2 overflow-x-auto pb-2">
        {CHIPS.map((c) => <button key={c} onClick={() => setCat(c)} className={`chip whitespace-nowrap px-4 py-1.5 text-sm ${cat === c ? "chip-wait" : "chip-muted"}`}>{c}</button>)}
      </div>

      <div className="mt-2 space-y-3">
        {isLoading && <div className="flex justify-center p-6"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>}
        {!isLoading && !visible.length && <p className="p-6 text-center text-sm text-muted-foreground">How can we help? Pick a topic and send us a message.</p>}
        {visible.map((m) => {
          const mine = m.sender === "user";
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${mine ? "rounded-br-sm bg-primary text-primary-foreground" : "rounded-bl-sm bg-muted text-foreground"}`}>
                {!mine && <div className="text-[11px] font-bold text-primary">{m.sender === "system" ? "Alpha Trade" : "Support"}</div>}
                {m.body && <p className="whitespace-pre-wrap break-words">{m.body}</p>}
                {m.image_path && <ChatImage path={m.image_path} />}
                <div className="mt-0.5 text-right text-[10px] opacity-60">{new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
              </div>
            </div>
          );
        })}
        <div ref={end} />
      </div>

      <form onSubmit={send} className="fixed inset-x-0 bottom-20 z-40 mx-auto max-w-md px-4">
        {file && <div className="mb-1 flex items-center gap-2 text-xs text-muted-foreground">{file.name}<button type="button" onClick={() => setFile(null)} aria-label="Remove image"><X className="h-3 w-3" /></button></div>}
        <div className="glass-card flex items-center gap-2 p-2">
          <label className="flex h-10 w-10 shrink-0 cursor-pointer items-center justify-center rounded-full bg-muted text-primary" aria-label="Attach image">
            <Plus className="h-5 w-5" />
            <input type="file" accept="image/*" className="hidden" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          </label>
          <input className="field flex-1 py-2" placeholder="Ask for help..." maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} />
          <button className="btn-primary h-10 w-10 shrink-0 p-0" disabled={busy} aria-label="Send">{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}</button>
        </div>
      </form>
      <BottomNav />
    </div>
  );
}
