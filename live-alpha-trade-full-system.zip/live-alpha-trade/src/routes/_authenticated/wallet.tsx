import { DotParticles } from "@/components/DotParticles";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowDownToLine, ArrowUpFromLine, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { BottomNav, TopBar } from "@/components/brand";
import { StatusChip } from "@/components/TradeRow";
import { memo } from "react";
import { money, useUserId, useWallet } from "@/lib/app-data";
import { useAssets, usePrices } from "./swap";

export const Route = createFileRoute("/_authenticated/wallet")({
  head: () => ({
    meta: [
      { title: "Wallet — Alpha Trade" },
      { name: "description", content: "Your balance, deposits and withdrawals." },
      { property: "og:title", content: "Wallet — Alpha Trade" },
      { property: "og:description", content: "Your balance, deposits and withdrawals." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: WalletPage,
});

function WalletPage() {
  const uid = useUserId();
  const { data: w } = useWallet();
  const { data } = useQuery({
    queryKey: ["wallet-history", uid],
    enabled: !!uid,
    queryFn: async () => {
      const [d, wd] = await Promise.all([
        supabase.from("deposits").select("id,amount,status,created_at").eq("user_id", uid!).order("created_at", { ascending: false }).limit(30),
        supabase.from("withdrawals").select("id,amount,fee,status,created_at,address").eq("user_id", uid!).order("created_at", { ascending: false }).limit(30),
      ]);
      return [
        ...(d.data ?? []).map((x) => ({ ...x, kind: "deposit" as const })),
        ...(wd.data ?? []).map((x) => ({ ...x, kind: "withdraw" as const })),
      ].sort((a, b) => b.created_at.localeCompare(a.created_at));
    },
  });

  return (
    <div className="page">
      <DotParticles />
      <TopBar />
      <section className="glass-card p-5">
        <div className="text-sm font-semibold uppercase tracking-wider text-cyan">Wallet Balance</div>
        <div className="balance-glow mt-1 text-5xl">{money(w?.balance)}</div>
        <div className="mt-1 text-xs text-muted-foreground">USDT · BEP20</div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <Link to="/deposit" className="btn-primary"><Plus className="h-5 w-5" /> Deposit</Link>
          <Link to="/withdraw" className="btn-outline">Withdraw</Link>
        </div>
      </section>
      <h2 className="mb-2 mt-6 font-semibold">Assets</h2>
      <Assets usdt={Number(w?.balance ?? 0)} />
      <h2 className="mb-2 mt-6 font-semibold">Transactions</h2>
      <div className="glass-card divide-y divide-border">
        {data?.length ? data.map((x) => (
          <div key={x.id} className="flex items-center gap-3 px-4 py-3">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full ${x.kind === "deposit" ? "chip-up" : "chip-wait"}`}>
              {x.kind === "deposit" ? <ArrowDownToLine className="h-4 w-4" /> : <ArrowUpFromLine className="h-4 w-4" />}
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold capitalize">{x.kind} · {money(x.amount)}</div>
              <div className="text-xs text-muted-foreground">{new Date(x.created_at).toLocaleString()}</div>
            </div>
            <StatusChip s={x.status} />
          </div>
        )) : <p className="p-5 text-center text-sm text-muted-foreground">No transactions yet</p>}
      </div>
      <BottomNav />
    </div>
  );
}

const AssetRow = memo(function AssetRow({ sym, qty, price }: { sym: string; qty: number; price?: number | undefined }) {
  return (
    <div className="flex items-center gap-3 px-4 py-3">
      <div className="flex-1">
        <div className="text-sm font-semibold">{sym}</div>
        <div className="text-xs text-muted-foreground">{qty.toLocaleString("en-US", { maximumFractionDigits: 8 })} · {price ? money(qty * price) : "…"}</div>
      </div>
      <Link to="/swap" search={{ from: sym }} className="btn-outline px-3 py-1.5 text-xs">Swap</Link>
    </div>
  );
});

function Assets({ usdt }: { usdt: number }) {
  const { data: assets = {} } = useAssets();
  const { data: prices = {} } = usePrices();
  const rows = [["USDT", usdt] as const, ...Object.entries(assets).filter(([, q]) => q > 0)];
  return (
    <div className="glass-card divide-y divide-border">
      {rows.map(([sym, qty]) => <AssetRow key={sym} sym={sym} qty={qty} price={prices[sym]} />)}
    </div>
  );
}
