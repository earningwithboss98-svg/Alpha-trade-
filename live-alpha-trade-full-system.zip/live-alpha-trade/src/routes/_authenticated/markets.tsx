import { DotParticles } from "@/components/DotParticles";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Search, TrendingDown, TrendingUp } from "lucide-react";
import { TopBar, BottomNav } from "@/components/brand";
import { marketTickers, type Ticker } from "@/lib/market.functions";
import { COINS_FALLBACK } from "@/data/coinsFallback";

export const Route = createFileRoute("/_authenticated/markets")({
  head: () => ({
    meta: [
      { title: "Markets — Alpha Trade" },
      { name: "description", content: "Live prices for BTC, ETH and 15+ coins." },
      { property: "og:title", content: "Markets — Alpha Trade" },
      { property: "og:description", content: "Live prices for BTC, ETH and 15+ coins." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Markets,
});

function Sparkline({ up }: { up: boolean }) {
  const pts = Array.from({ length: 20 }, (_, i) => {
    const y = 24 - (up ? i * 0.9 : (20 - i) * 0.9) - Math.sin(i * 1.7) * 4;
    return `${i * 8},${Math.max(2, Math.min(30, y))}`;
  }).join(" ");
  return (
    <svg width="80" height="32" viewBox="0 0 152 32" className="shrink-0">
      <polyline points={pts} fill="none" stroke={up ? "var(--up)" : "var(--down)"} strokeWidth="2" />
    </svg>
  );
}

const CACHE = "at_markets_v1";

async function browserBinance(): Promise<Ticker[]> {
  const r = await fetch("https://data-api.binance.vision/api/v3/ticker/24hr");
  if (!r.ok) throw new Error("binance");
  const rows: Record<string, string>[] = await r.json();
  return rows.filter((x) => x["symbol"]?.endsWith("USDT") && Number(x["lastPrice"]) > 0)
    .sort((a, b) => Number(b["quoteVolume"]) - Number(a["quoteVolume"])).slice(0, 100)
    .map((x) => ({ symbol: x["symbol"]!.replace(/USDT$/, ""), price: Number(x["lastPrice"]), change: Number(x["priceChangePercent"]), high: Number(x["highPrice"]), low: Number(x["lowPrice"]) }));
}

async function loadTickers(): Promise<{ tickers: Ticker[]; live: boolean }> {
  try {
    const r = await marketTickers();
    if (r.tickers.length) { localStorage.setItem(CACHE, JSON.stringify(r.tickers)); return { tickers: r.tickers, live: true }; }
  } catch { /* next */ }
  try {
    const t = await browserBinance();
    if (t.length) { localStorage.setItem(CACHE, JSON.stringify(t)); return { tickers: t, live: true }; }
  } catch { /* next */ }
  try { const c = JSON.parse(localStorage.getItem(CACHE) ?? "[]"); if (c.length) return { tickers: c, live: false }; } catch { /* ignore */ }
  return { tickers: COINS_FALLBACK, live: false };
}

function Markets() {
  const [q, setQ] = useState("");
  const [dq, setDq] = useState("");
  useEffect(() => { const t = setTimeout(() => setDq(q), 200); return () => clearTimeout(t); }, [q]);
  const { data, refetch, isFetching } = useQuery({
    queryKey: ["markets"],
    queryFn: loadTickers,
    placeholderData: { tickers: COINS_FALLBACK, live: false },
    staleTime: 30_000,
    refetchInterval: 30_000,
  });
  const isLoading = false, isError = false;
  const list = useMemo(() => (data?.tickers ?? []).filter((t) => !dq || (t.symbol + " " + (t.name ?? "")).toLowerCase().includes(dq.toLowerCase())), [data, dq]);
  return (
    <div className="page">
      <DotParticles />
      <TopBar />
      <div className="relative">
        <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
        <input className="field pl-11" placeholder="Search coins…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      {!data?.live && <div className="mt-3 flex items-center justify-between rounded-xl border border-primary/30 bg-primary/10 px-3 py-2 text-xs text-primary">Prices delayed — reconnecting to live feed <button className="font-bold" onClick={() => refetch()}>{isFetching ? "…" : "Retry"}</button></div>}
      <div className="mt-4 space-y-2">
        {isLoading && Array.from({ length: 8 }).map((_, i) => <div key={i} className="glass-card h-16 animate-pulse" />)}
        {list.map((t) => {
          const up = t.change >= 0;
          return (
            <Link key={t.symbol} to="/dashboard" className="glass-card fade-up flex items-center gap-3 p-3">
              {t.image
                ? <img src={t.image} alt={t.symbol} width={40} height={40} className="h-10 w-10 rounded-full" loading="lazy" />
                : <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/15 font-bold text-primary">{t.symbol.slice(0, 1)}</div>}
              <div className="min-w-0 flex-1">
                <div className="font-bold">{t.symbol}<span className="text-xs font-medium text-muted-foreground">/USDT</span></div>
                {t.name && <div className="truncate text-xs text-muted-foreground">{t.name}</div>}
                <div className="text-xs text-muted-foreground">H {t.high.toLocaleString("en-US", { maximumFractionDigits: 4 })} · L {t.low.toLocaleString("en-US", { maximumFractionDigits: 4 })}</div>
              </div>
              <Sparkline up={up} />
              <div className="text-right">
                <div className="font-bold tabular-nums">${t.price.toLocaleString("en-US", { maximumFractionDigits: t.price < 1 ? 6 : 2 })}</div>
                <div className={`inline-flex items-center gap-1 text-xs font-bold ${up ? "text-up" : "text-down"}`}>
                  {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {up ? "+" : ""}{t.change.toFixed(2)}%
                </div>
              </div>
            </Link>
          );
        })}
        {!isLoading && !list.length && (q
          ? <p className="p-6 text-center text-muted-foreground">No coins match "{q}"</p>
          : <div className="glass-card p-6 text-center text-sm text-muted-foreground">{isError ? "Prices are reconnecting…" : "Loading coins…"} <button className="ml-2 font-semibold text-primary" onClick={() => refetch()}>Retry</button></div>)}
      </div>
      <BottomNav />
    </div>
  );
}
