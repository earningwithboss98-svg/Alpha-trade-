import { DotParticles } from "@/components/DotParticles";
import { createFileRoute, Link } from "@tanstack/react-router";
import { lazy, Suspense, useCallback, useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  ArrowDown, ArrowUp, ArrowUpDown, Check, Clock3, Headset, Info, Maximize2, Minimize2, Minus, MoreHorizontal, Plus, RefreshCw, Wallet as WalletIcon, ZoomIn, ZoomOut,
} from "lucide-react";
import { TopBar, BottomNav, ShiningAvatar } from "@/components/brand";
import { BonusCard } from "@/components/BonusCard";
import type { LiveChartHandle } from "@/components/LiveChart";
import { ProfileGreeting } from "@/components/ProfileGreeting";
import { ResultModal, WelcomeModal } from "@/components/modals";
import { DURATIONS, errMsg, fmtTimer, money, useProfile, useSettings, useTrades, useWallet } from "@/lib/app-data";
import { openTrade, settleTrade, settleExpired } from "@/lib/trade.functions";
import { TradeRow } from "@/components/TradeRow";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — Alpha Trade" },
      { name: "description", content: "Live BTC/USDT chart, balance and trading." },
      { property: "og:title", content: "Dashboard — Alpha Trade" },
      { property: "og:description", content: "Live BTC/USDT chart, balance and trading." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

type Active = { id: string; side: "up" | "down"; amount: number; expiresAt: number; openPrice: number };
const LiveChart = lazy(() => import("@/components/LiveChart").then((module) => ({ default: module.LiveChart })));

function Dashboard() {
  const qc = useQueryClient();
  const { data: wallet } = useWallet();
  const { data: profile } = useProfile();
  const { data: settings } = useSettings();
  const { data: trades } = useTrades(8);
  const chart = useRef<LiveChartHandle>(null);
  const [price, setPrice] = useState<number | null>(null);
  const [chg, setChg] = useState(0);
  const [status, setStatus] = useState("Loading");
  const [duration, setDuration] = useState(15);
  const [amount, setAmount] = useState(1);
  const [timerOpen, setTimerOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [info, setInfo] = useState(false);
  const [full, setFull] = useState(false);
  const [active, setActive] = useState<Active | null>(null);
  const [left, setLeft] = useState(0);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ status: string; amount: number; profit: number; payout: number } | null>(null);
  const [welcome, setWelcome] = useState<"new" | "back" | null>(null);
  const open = useServerFn(openTrade);
  const settle = useServerFn(settleTrade);
  const sweep = useServerFn(settleExpired);

  const minT = Number(settings?.min_trade ?? 1), maxT = Number(settings?.max_trade ?? 1000);

  useEffect(() => { sweep().then((r) => { if (r.settled) qc.invalidateQueries(); }).catch(() => {}); }, [sweep, qc]);

  // Welcome cards
  useEffect(() => {
    if (!profile) return;
    const key = `at_welcomed_${profile.id}`;
    const fresh = Date.now() - new Date(profile.created_at).getTime() < 30 * 60_000;
    if (fresh && !localStorage.getItem(key)) { setWelcome("new"); localStorage.setItem(key, "1"); sessionStorage.removeItem("at_welcome"); }
    else if (sessionStorage.getItem("at_welcome") === "back") { setWelcome("back"); sessionStorage.removeItem("at_welcome"); localStorage.setItem(key, "1"); }
  }, [profile]);

  // Countdown + settle
  useEffect(() => {
    if (!active) return;
    let done = false;
    const iv = setInterval(async () => {
      const ms = active.expiresAt - Date.now();
      setLeft(Math.max(0, Math.ceil(ms / 1000)));
      if (ms <= -800 && !done) {
        done = true;
        clearInterval(iv);
        for (let i = 0; i < 6; i++) {
          try {
            const t = await settle({ data: { id: active.id } });
            if (t.status !== "open") {
              setResult({ status: t.status, amount: Number(t.amount), profit: Number(t.profit), payout: Number(t.payout) });
              break;
            }
          } catch { /* retry */ }
          await new Promise((r) => setTimeout(r, 1200));
        }
        chart.current?.setEntry(null);
        setActive(null);
        qc.invalidateQueries({ queryKey: ["wallet"] });
        qc.invalidateQueries({ queryKey: ["trades"] });
      }
    }, 200);
    return () => clearInterval(iv);
  }, [active, settle, qc]);

  const trade = async (side: "up" | "down") => {
    if (active) { toast.info("Wait for your current trade to finish"); return; }
    if (amount < minT || amount > maxT) { toast.error(`Trade amount must be ${minT} - ${maxT} USDT`); return; }
    if (Number(wallet?.balance ?? 0) < amount) { toast.error("Insufficient balance. Please deposit."); return; }
    setBusy(true);
    try {
      const t = await open({ data: { side, amount, duration } });
      const a: Active = { id: t.id, side, amount: Number(t.amount), expiresAt: new Date(t.expires_at).getTime(), openPrice: Number(t.open_price) };
      setActive(a);
      setLeft(duration);
      chart.current?.setEntry(a.openPrice, side);
      qc.invalidateQueries({ queryKey: ["wallet"] });
    } catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };

  const refresh = useCallback(() => {
    setMenuOpen(false);
    qc.invalidateQueries();
    chart.current?.reload();
    toast.success("Refreshed");
  }, [qc]);

  const winning = active && price != null ? (active.side === "up" ? price > active.openPrice : price < active.openPrice) : null;

  const overlay = active && (
    <div className={`pointer-events-none absolute left-3 top-12 z-10 rounded-xl px-3 py-2 text-sm font-bold ${active.side === "up" ? "chip-up" : "chip-down"}`}>
      {active.side === "up" ? "UP" : "DOWN"} {money(active.amount)} - {fmtTimer(left).slice(3)}
      <div className={`text-[11px] font-semibold ${winning ? "text-up" : "text-down"}`}>{winning ? "In profit" : "Out of profit"}</div>
    </div>
  );

  const timerDropdown = timerOpen && (
    <div className="menu-pop right-0 top-12 w-44">
      {DURATIONS.map((d) => (
        <button key={d.s} onClick={() => { setDuration(d.s); setTimerOpen(false); }}
          className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm ${duration === d.s ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`}>
          {d.label} {duration === d.s && <Check className="h-4 w-4" />}
        </button>
      ))}
    </div>
  );

  const amountCtl = (
    <div className="flex items-center gap-3 rounded-2xl bg-muted/60 p-2">
      <button aria-label="Decrease" className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-primary text-primary" onClick={() => setAmount((a) => Math.max(minT, +(a - 1).toFixed(2)))}><Minus /></button>
      <div className="flex flex-1 items-baseline justify-center gap-1">
        <input inputMode="decimal" value={amount} onChange={(e) => setAmount(Math.max(0, Number(e.target.value.replace(/[^\d.]/g, "")) || 0))}
          className="w-20 bg-transparent text-center text-2xl font-bold outline-none" aria-label="Investment amount" />
        <span className="text-lg font-bold">USDT</span>
      </div>
      <button aria-label="Increase" className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-primary text-primary" onClick={() => setAmount((a) => Math.min(maxT, +(a + 1).toFixed(2)))}><Plus /></button>
    </div>
  );

  const buySell = (
    <div className="grid grid-cols-2 gap-3">
      <button className="btn-up" disabled={busy || !!active} onClick={() => trade("up")}><ArrowUp /> Buy</button>
      <button className="btn-down" disabled={busy || !!active} onClick={() => trade("down")}><ArrowDown /> Sell</button>
    </div>
  );

  const chartHeader = (
    <div className="flex items-center justify-between px-4 pt-3">
      <div className="text-sm font-medium">BTC/USDT · 1m · <span className={status === "Live" ? "text-up" : "text-muted-foreground"}>{status === "Live" && <span className="live-dot mr-1" />}{status}</span></div>
      <div className="relative flex items-center gap-1">
        <button aria-label={full ? "Exit fullscreen" : "Fullscreen"} className="rounded-lg p-2 hover:bg-muted" onClick={() => setFull((f) => !f)}>
          {full ? <Minimize2 className="h-5 w-5" /> : <Maximize2 className="h-5 w-5" />}
        </button>
        <button aria-label="Chart menu" className="rounded-lg p-2 hover:bg-muted" onClick={() => setMenuOpen((m) => !m)}><MoreHorizontal className="h-5 w-5" /></button>
        {menuOpen && (
          <div className="menu-pop right-0 top-10 w-44">
            <button onClick={refresh} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-muted"><RefreshCw className="h-4 w-4" /> Refresh</button>
            <button onClick={() => { setInfo(true); setMenuOpen(false); }} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-muted"><Info className="h-4 w-4" /> Market Info</button>
          </div>
        )}
      </div>
    </div>
  );

  const priceLine = (
    <div className="px-4 pb-3">
      <span className="rounded-md bg-accent px-2 py-0.5 text-sm text-cyan">{price ? price.toLocaleString("en-US", { minimumFractionDigits: 2 }) : "—"} USDT</span>
      <div className={`mt-1 text-sm font-medium ${chg >= 0 ? "text-up" : "text-down"}`}>{chg >= 0 ? "+" : ""}{chg.toFixed(2)}% <span className="text-muted-foreground">(100m)</span></div>
    </div>
  );

  const onPrice = useCallback((p: number, c: number) => { setPrice(p); setChg(c); }, []);
  const chartEl = <Suspense fallback={<div className="h-full w-full" />}><LiveChart ref={chart} height="100%" onPrice={onPrice} onStatus={setStatus} /></Suspense>;

  if (full) {
    return (
      <div className="fixed inset-0 z-[9000] flex flex-col bg-background" style={{ height: "100dvh" }}>
        {chartHeader}
        <div className="relative min-h-0 flex-1">{overlay}{chartEl}</div>
        <div className="space-y-2 border-t p-3" style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}>
          <div className="relative flex items-center gap-2">
            <button className="btn-outline flex-1 py-2" onClick={() => setTimerOpen((o) => !o)}><Clock3 className="h-4 w-4" /> {active ? fmtTimer(left) : fmtTimer(duration)} <ArrowUpDown className="h-4 w-4" /></button>
            <button aria-label="Zoom out" className="btn-outline px-3 py-2" onClick={() => chart.current?.zoom(-1)}><ZoomOut className="h-4 w-4" /></button>
            <button aria-label="Zoom in" className="btn-outline px-3 py-2" onClick={() => chart.current?.zoom(1)}><ZoomIn className="h-4 w-4" /></button>
            {timerOpen && <div className="absolute bottom-14 left-0">{<div className="menu-pop bottom-0 left-0 w-44">{DURATIONS.map((d) => (
              <button key={d.s} onClick={() => { setDuration(d.s); setTimerOpen(false); }} className={`flex w-full justify-between rounded-lg px-3 py-2 text-sm ${duration === d.s ? "bg-primary text-primary-foreground" : ""}`}>{d.label}{duration === d.s && <Check className="h-4 w-4" />}</button>))}</div>}</div>}
          </div>
          {amountCtl}
          {buySell}
        </div>
        {result && <ResultModal result={result} onClose={() => setResult(null)} />}
      </div>
    );
  }

  return (
    <div className="page">
      <DotParticles />
      <TopBar />

      <div className="fade-up mb-4 flex items-center gap-3">
        <Link to="/profile" aria-label="Profile" className="shrink-0"><ShiningAvatar size={56} url={profile?.avatar_url} name={profile?.name} /></Link>
        <div className="min-w-0 flex-1"><div className="truncate font-bold">Hi {profile?.name ?? "Trader"}</div><ProfileGreeting trading={!!active || !!trades?.some((t) => t.status === "open" && new Date(t.expires_at).getTime() > Date.now())} /></div>
      </div>

      <section className="glass-card gold-glow fade-up relative overflow-hidden p-5">
        <div className="particles" aria-hidden /><DotParticles count={15} contained />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-primary"><WalletIcon className="h-5 w-5" /> Available Balance</div>
        </div>
        <div className="relative mt-1 text-5xl font-extrabold tracking-tight">{money(wallet?.balance)}</div>
        <Button asChild variant="outline" size="icon" className="absolute right-4 top-1/2 z-10 h-9 w-9 -translate-y-1/2 rounded-full border-primary/50 bg-primary/15 text-primary"><Link to="/support" aria-label="Balance support" title="Customer Support"><Headset /></Link></Button>
        <div className="relative"><BonusCard /></div>
      </section>

      <div className="fade-up mt-5 flex items-center justify-between">
        <h2 className="text-xl font-bold">Live Market</h2>
        <span className={`text-sm font-semibold ${chg >= 0 ? "text-up" : "text-down"}`}><span className="text-primary">BTC/USD</span> · {chg >= 0 ? "+" : ""}{chg.toFixed(2)}%</span>
      </div>

      <section className="glass-card relative mt-3 overflow-visible">
        {chartHeader}
        <div className="pointer-events-none absolute inset-x-0 top-12 z-[5] text-center">
          <div className="text-xs font-semibold text-muted-foreground">BTC/USD · LIVE</div>
          <div className="text-3xl font-extrabold text-primary tabular-nums">{price ? price.toFixed(2) : <span className="text-base">Connecting…</span>}</div>
        </div>
        <div className="relative h-80 w-full min-w-0 overflow-hidden">
          {overlay}{chartEl}
          <div className="absolute bottom-8 left-3 z-10 flex gap-1">
            <Button variant="outline" size="icon" className="h-8 w-8 text-primary" aria-label="Zoom out" title="Zoom out" onClick={() => chart.current?.zoom(-1)}><ZoomOut /></Button>
            <Button variant="outline" size="icon" className="h-8 w-8 text-primary" aria-label="Zoom in" title="Zoom in" onClick={() => chart.current?.zoom(1)}><ZoomIn /></Button>
          </div>
        </div>
        {priceLine}
      </section>

      <section className="relative mt-4" style={{ zIndex: timerOpen ? 9999 : undefined }}>
        <button className="hex-timer mx-auto flex w-64 flex-col items-center py-3" onClick={() => setTimerOpen((o) => !o)} aria-label="Choose timer">
          <span className="text-xs font-semibold">{active ? "Trade ends in" : "Timer"} <ArrowUpDown className="inline h-3 w-3" /></span>
          <span className="text-3xl font-extrabold tabular-nums text-primary">{active ? fmtTimer(left) : fmtTimer(duration)}</span>
        </button>
        <div className="absolute right-1/2 top-16 translate-x-1/2">{timerDropdown}</div>
      </section>

      <section id="trade-panel" className="mt-4 space-y-3">
        <div className="flex justify-between text-sm font-semibold">
          <span>Investment Amount</span><span className="text-muted-foreground">Payout {Number(settings?.profit_percent ?? 95)}%</span>
        </div>
        {amountCtl}
        {buySell}
      </section>



      <BottomNav />
      {(timerOpen || menuOpen) && <div className="fixed inset-0 z-[9998]" onClick={() => { setTimerOpen(false); setMenuOpen(false); }} />}
      {info && (
        <div className="modal-backdrop" onClick={() => setInfo(false)}>
          <div className="modal-card text-left" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold">Market Info</h3>
            <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
              <li>Pair: <b className="text-foreground">BTC/USDT</b> (Binance spot)</li>
              <li>Last price: <b className="text-foreground">{price?.toFixed(2)}</b></li>
              <li>Timers: 15s – 300s</li>
              <li>Payout on win: <b className="text-foreground">{Number(settings?.profit_percent ?? 95)}%</b> of investment</li>
              <li>Trade limits: {minT} – {maxT} USDT</li>
              <li>Result uses the Binance price at the exact second your timer ends.</li>
            </ul>
            <button className="btn-primary mt-5 w-full" onClick={() => setInfo(false)}>Close</button>
          </div>
        </div>
      )}
      {welcome && <WelcomeModal kind={welcome} onClose={() => setWelcome(null)} />}
      {result && <ResultModal result={result} onClose={() => setResult(null)} />}
    </div>
  );
}
