import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowDownUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { BottomNav, TopBar } from "@/components/brand";
import { errMsg, useUserId, useWallet } from "@/lib/app-data";
import { marketTickers } from "@/lib/market.functions";
import { SWAP_COINS, swapCoins } from "@/lib/swap.functions";

type Coin = (typeof SWAP_COINS)[number];

export const Route = createFileRoute("/_authenticated/swap")({
  validateSearch: (s: Record<string, unknown>): { from?: string } => (typeof s["from"] === "string" ? { from: s["from"] } : {}),
  head: () => ({
    meta: [
      { title: "Swap — Alpha Trade" },
      { name: "description", content: "Swap USDT and crypto coins at live prices." },
      { property: "og:title", content: "Swap — Alpha Trade" },
      { property: "og:description", content: "Swap coins at live prices." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SwapPage,
});

export function useAssets() {
  const uid = useUserId();
  return useQuery({
    queryKey: ["assets", uid], enabled: !!uid, staleTime: 30_000,
    queryFn: async () => {
      const { data } = await supabase.from("wallet_assets").select("symbol,qty").eq("user_id", uid!);
      return Object.fromEntries((data ?? []).map((a) => [a.symbol, Number(a.qty)])) as Record<string, number>;
    },
  });
}

export function usePrices() {
  return useQuery({
    queryKey: ["tickers"], refetchInterval: 10_000, staleTime: 10_000,
    queryFn: async () => {
      const { tickers } = await marketTickers();
      return { USDT: 1, ...Object.fromEntries(tickers.map((t) => [t.symbol, t.price])) } as Record<string, number>;
    },
  });
}

const fmt = (n: number) => n >= 1 ? n.toLocaleString("en-US", { maximumFractionDigits: 4 }) : n.toPrecision(4);

function SwapPage() {
  const search = Route.useSearch();
  const uid = useUserId();
  const qc = useQueryClient();
  const { data: w } = useWallet();
  const { data: assets = {} } = useAssets();
  const { data: prices = {} } = usePrices();
  const init = (SWAP_COINS as readonly string[]).includes(search.from ?? "") ? (search.from as Coin) : "USDT";
  const [from, setFrom] = useState<Coin>(init);
  const [to, setTo] = useState<Coin>(init === "BTC" ? "USDT" : "BTC");
  const [amount, setAmount] = useState("");
  const [busy, setBusy] = useState(false);

  const bal = (c: string) => (c === "USDT" ? Number(w?.balance ?? 0) : assets[c] ?? 0);
  const fp = prices[from], tp = prices[to];
  const amt = Number(amount) || 0;
  const fee = amt * 0.002;
  const out = fp && tp ? ((amt - fee) * fp) / tp : 0;

  const { data: history = [] } = useQuery({
    queryKey: ["swaps", uid], enabled: !!uid,
    queryFn: async () => (await supabase.from("swaps").select("*").eq("user_id", uid!).order("created_at", { ascending: false }).limit(10)).data ?? [],
  });

  const options = useMemo(() => SWAP_COINS.map((c) => <option key={c} value={c}>{c}</option>), []);

  const submit = async (): Promise<void> => {
    if (amt <= 0) { toast.error("Enter an amount"); return; }
    if (amt > bal(from)) { toast.error(`Insufficient ${from} balance`); return; }
    setBusy(true);
    try {
      await swapCoins({ data: { from, to, amount: amt } });
      toast.success(`Swapped ${fmt(amt)} ${from} → ${fmt(out)} ${to}`);
      setAmount("");
      qc.invalidateQueries({ queryKey: ["wallet"] }); qc.invalidateQueries({ queryKey: ["assets"] }); qc.invalidateQueries({ queryKey: ["swaps"] });
    } catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };

  return (
    <div className="page">
      <TopBar />
      <section className="glass-card space-y-4 p-5">
        <h1 className="text-xl font-bold">Swap</h1>
        <div>
          <div className="flex justify-between text-xs text-muted-foreground"><span>From</span><span>Balance: {fmt(bal(from))} {from}</span></div>
          <div className="mt-1 flex gap-2">
            <select className="field w-28" value={from} onChange={(e) => setFrom(e.target.value as Coin)}>{options}</select>
            <input className="field flex-1" inputMode="decimal" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} />
            <button className="btn-outline px-3 text-xs" onClick={() => setAmount(String(bal(from)))}>MAX</button>
          </div>
        </div>
        <button className="mx-auto flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground" aria-label="Switch" onClick={() => { setFrom(to); setTo(from); }}><ArrowDownUp className="h-4 w-4" /></button>
        <div>
          <div className="flex justify-between text-xs text-muted-foreground"><span>To</span><span>Balance: {fmt(bal(to))} {to}</span></div>
          <div className="mt-1 flex gap-2">
            <select className="field w-28" value={to} onChange={(e) => setTo(e.target.value as Coin)}>{options}</select>
            <div className="field flex-1">{out ? fmt(out) : "0.00"}</div>
          </div>
        </div>
        <div className="space-y-1 rounded-xl bg-muted/60 p-3 text-sm">
          <div className="flex justify-between"><span className="text-muted-foreground">Rate</span><span>{fp && tp ? `1 ${from} = ${fmt(fp / tp)} ${to}` : "Loading…"}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Fee (0.2%)</span><span>{fmt(fee)} {from}</span></div>
        </div>
        <button className="btn-primary w-full" disabled={busy || from === to} onClick={submit}>{busy ? "Swapping…" : "SWAP"}</button>
      </section>
      <h2 className="mb-2 mt-6 font-semibold">Recent swaps</h2>
      <div className="glass-card divide-y divide-border">
        {history.length ? history.map((s) => (
          <div key={s.id} className="flex justify-between px-4 py-3 text-sm">
            <span>{fmt(Number(s.from_amount))} {s.from_symbol} → {fmt(Number(s.to_amount))} {s.to_symbol}</span>
            <span className="text-xs text-muted-foreground">{new Date(s.created_at).toLocaleString()}</span>
          </div>
        )) : <p className="p-5 text-center text-sm text-muted-foreground">No swaps yet</p>}
      </div>
      <BottomNav />
    </div>
  );
}
