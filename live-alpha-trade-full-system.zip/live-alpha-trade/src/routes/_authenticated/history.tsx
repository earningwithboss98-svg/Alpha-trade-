import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { BottomNav, TopBar } from "@/components/brand";
import { TradeRow } from "@/components/TradeRow";
import { money, useTrades } from "@/lib/app-data";

export const Route = createFileRoute("/_authenticated/history")({
  head: () => ({
    meta: [
      { title: "Trade History — Alpha Trade" },
      { name: "description", content: "Your BTC/USDT trade results." },
      { property: "og:title", content: "Trade History — Alpha Trade" },
      { property: "og:description", content: "Your BTC/USDT trade results." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HistoryPage,
});

function HistoryPage() {
  const { data } = useTrades(200);
  const [filter, setFilter] = useState<"all" | "24h">("24h");
  const list = (data ?? []).filter((t) => filter === "all" || Date.now() - new Date(t.opened_at).getTime() < 86_400_000);
  const wins = list.filter((t) => t.status === "win"), losses = list.filter((t) => t.status === "loss");
  const net = wins.reduce((a, t) => a + Number(t.profit), 0) - losses.reduce((a, t) => a + Number(t.amount), 0);
  return (
    <div className="page">
      <TopBar />
      <h1 className="text-2xl font-bold">History</h1>
      <div className="mt-4 grid grid-cols-3 gap-3 text-center">
        <div className="glass-card p-3"><div className="text-xs text-muted-foreground">Wins</div><div className="text-xl font-bold text-up">{wins.length}</div></div>
        <div className="glass-card p-3"><div className="text-xs text-muted-foreground">Losses</div><div className="text-xl font-bold text-down">{losses.length}</div></div>
        <div className="glass-card p-3"><div className="text-xs text-muted-foreground">Net</div><div className={`text-xl font-bold ${net >= 0 ? "text-up" : "text-down"}`}>{money(net)}</div></div>
      </div>
      <div className="mt-4 flex gap-2">
        {(["24h", "all"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`chip px-3 py-1 ${filter === f ? "chip-wait" : "chip-muted"}`}>{f === "24h" ? "Last 24h" : "All"}</button>
        ))}
      </div>
      <div className="glass-card mt-3 divide-y divide-border">
        {list.length ? list.map((t) => <TradeRow key={t.id} t={t} />) : <p className="p-5 text-center text-sm text-muted-foreground">No trades in this period</p>}
      </div>
      <BottomNav />
    </div>
  );
}
