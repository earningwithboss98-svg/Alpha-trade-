import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, Clock3 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { BottomNav } from "@/components/brand";
import { errMsg, money, useSettings, useWallet, type Settings } from "@/lib/app-data";

export const Route = createFileRoute("/_authenticated/withdraw")({
  head: () => ({
    meta: [
      { title: "Withdraw USDT — Alpha Trade" },
      { name: "description", content: "Withdraw USDT to your own BEP20 address." },
      { property: "og:title", content: "Withdraw USDT — Alpha Trade" },
      { property: "og:description", content: "Withdraw USDT to your BEP20 address." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Withdraw,
});

const DAY = ["", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const hm = (t: string) => {
  const [h = 0, m = 0] = t.split(":").map(Number);
  return `${((h + 11) % 12) + 1}${m ? ":" + String(m).padStart(2, "0") : ""}${h < 12 ? "AM" : "PM"}`;
};

export function withdrawWindow(s: Settings, now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: s.withdraw_timezone, weekday: "short", hour: "2-digit", minute: "2-digit", hour12: false }).formatToParts(now);
  const wd = parts.find((p) => p.type === "weekday")?.value ?? "Mon";
  const hhmm = `${parts.find((p) => p.type === "hour")?.value}:${parts.find((p) => p.type === "minute")?.value}`;
  const dow = DAY.indexOf(wd);
  const open = s.withdraw_days.includes(dow) && hhmm >= s.withdraw_start.slice(0, 5) && hhmm <= s.withdraw_end.slice(0, 5);
  const label = `${hm(s.withdraw_start)}-${hm(s.withdraw_end)} ${s.withdraw_days.map((d) => DAY[d]).join(", ")}`;
  return { open, label };
}

function Withdraw() {
  const { data: s } = useSettings();
  const { data: w } = useWallet();
  const qc = useQueryClient();
  const nav = useNavigate();
  const [amount, setAmount] = useState("");
  const [address, setAddress] = useState("");
  const [busy, setBusy] = useState(false);
  if (!s) return <div className="page" />;
  const min = Number(s.min_withdraw), max = Number(s.max_withdraw);
  const n = Number(amount);
  const fee = n ? Math.round((n * Number(s.withdraw_fee_percent) / 100 + Number(s.withdraw_fee_fixed)) * 100) / 100 : 0;
  const win = withdrawWindow(s);
  const err = amount && (n < min ? `Minimum withdrawal is ${min} USDT` : n > max ? `Maximum withdrawal is ${max} USDT` : n > Number(w?.balance ?? 0) ? "Insufficient balance" : "");

  const submit = async () => {
    if (!win.open) { toast.error(`Withdraw available ${win.label}`); return; }
    if (!n || err) { toast.error(err || "Enter an amount"); return; }
    if (!/^0x[a-fA-F0-9]{40}$/.test(address.trim())) { toast.error("Enter a valid BEP20 address (0x…)"); return; }
    setBusy(true);
    try {
      const { error } = await supabase.rpc("request_withdrawal", { _amount: n, _address: address.trim() });
      if (error) throw error;
      toast.success("Withdrawal submitted — pending review");
      qc.invalidateQueries();
      nav({ to: "/wallet" });
    } catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };

  return (
    <div className="page pt-5">
      <Link to="/dashboard" className="mb-4 inline-flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Back</Link>
      <h1 className="text-2xl font-bold">Withdraw USDT</h1>
      <p className="mt-1 text-sm text-muted-foreground">Available: <b className="text-cyan">{money(w?.balance)}</b></p>
      {!win.open && (
        <div className="mt-4 flex items-center gap-2 rounded-xl border border-primary bg-accent p-3 text-sm"><Clock3 className="h-4 w-4 text-primary" /> Withdraw available {win.label}</div>
      )}
      <div className="glass-card mt-4 space-y-5 p-5">
        <div>
          <label className="label">Amount</label>
          <div className="relative">
            <input inputMode="decimal" className="field pr-20 text-2xl font-bold" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))} />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 font-semibold text-muted-foreground">USDT</span>
          </div>
          <p className={`mt-1.5 text-xs ${err ? "text-down" : "text-muted-foreground"}`}>{err || `Min ${min} · Max ${max} USDT`}</p>
        </div>
        <div>
          <label className="label">Your BEP20 Address</label>
          <input className="field font-mono text-sm" placeholder="0x…" value={address} onChange={(e) => setAddress(e.target.value)} />
        </div>
        <div className="space-y-1 rounded-xl bg-muted/60 p-3 text-sm">
          <div className="flex justify-between"><span className="text-muted-foreground">Fee ({Number(s.withdraw_fee_percent)}%{Number(s.withdraw_fee_fixed) ? ` + $${Number(s.withdraw_fee_fixed)}` : ""})</span><span>{money(fee)}</span></div>
          <div className="flex justify-between font-semibold"><span>You receive</span><span className="text-up">{money(Math.max(0, n - fee))}</span></div>
        </div>
        <p className="text-xs text-muted-foreground">{s.withdraw_instructions}</p>
        <button className="btn-primary w-full" disabled={busy || !win.open} onClick={submit}>{busy ? "Submitting…" : "Submit Withdrawal"}</button>
      </div>
      <BottomNav />
    </div>
  );
}
