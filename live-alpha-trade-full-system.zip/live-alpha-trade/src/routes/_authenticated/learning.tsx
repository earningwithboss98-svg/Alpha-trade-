import { DotParticles } from "@/components/DotParticles";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDownToLine, ArrowUpFromLine, Bitcoin, Headset, Timer } from "lucide-react";
import { BottomNav, TopBar } from "@/components/brand";
import { useSettings } from "@/lib/app-data";

export const Route = createFileRoute("/_authenticated/learning")({
  head: () => ({
    meta: [
      { title: "Learning — Alpha Trade" },
      { name: "description", content: "Learn BTC trading, deposits, timers and withdrawals." },
      { property: "og:title", content: "Learning — Alpha Trade" },
      { property: "og:description", content: "Learn how Alpha Trade works." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Learning,
});

function Learning() {
  const { data: s } = useSettings();
  const cards = [
    { icon: Bitcoin, t: "What is BTC Trading", d: "Bitcoin (BTC) price against Tether (USDT) moves every second. Here you predict whether BTC/USDT will be higher or lower when your timer ends, using the live Binance market price." },
    { icon: ArrowDownToLine, t: "How Deposit Works", d: `Tap Deposit, enter an amount (${s?.min_deposit ?? 5}–${s?.max_deposit ?? 5000} USDT). Tap "Show QR Code" to see the BEP20 address — scan it from your wallet or copy it. Send only USDT on BNB Smart Chain, then upload a screenshot of the transfer and tap Verify & Submit. Your balance updates once approved.` },
    { icon: Timer, t: "How to Trade Up/Down", d: `Pick a timer from 15 seconds to 5 minutes with the ↕ button, set your investment, then tap Buy (Up) or Sell (Down). Your entry price is marked on the chart. When the timer ends, if the price moved your way you receive your payout instantly.` },
    { icon: ArrowUpFromLine, t: "How to Withdraw", d: `Tap Withdraw, enter ${s?.min_withdraw ?? 10}–${s?.max_withdraw ?? 5000} USDT and your own BEP20 address. A fee of ${s?.withdraw_fee_percent ?? 2}% applies. Withdrawals can be requested ${s?.withdraw_start?.slice(0, 5) ?? "09:00"}–${s?.withdraw_end?.slice(0, 5) ?? "17:00"} on working days.` },
  ];
  return (
    <div className="page">
      <DotParticles />
      <TopBar />
      <div className="flex items-center justify-between"><h1 className="text-2xl font-bold">Learning</h1><Link to="/support" aria-label="Support" className="flex h-9 w-9 items-center justify-center rounded-full border border-primary/40 bg-primary/15 text-primary"><Headset className="h-4 w-4" /></Link></div>
      <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">{["₿","Ξ","₿","Ξ","₿","Ξ","₿","Ξ"].map((c, i) => <span key={i} className="dot-rise" style={{ left: `${8 + i * 12}%`, fontSize: 10, opacity: 0.3, color: "var(--primary)", animationDuration: "15s", animationDelay: `${i * 1.8}s` }}>{c}</span>)}</div>
      <Link to="/markets" className="glass-card gold-glow mt-4 block p-4"><div className="font-bold text-primary">Trade Multiple Coins on Alpha Trade</div><div className="text-sm text-muted-foreground">100+ coins with live prices →</div></Link>
      <div className="mt-4 space-y-4">
        {cards.map(({ icon: I, t, d }) => (
          <article key={t} className="glass-card p-5">
            <div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent"><I className="h-5 w-5 text-primary" /></div><h2 className="font-semibold">{t}</h2></div>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{d}</p>
          </article>
        ))}
      </div>
      <BottomNav />
    </div>
  );
}
