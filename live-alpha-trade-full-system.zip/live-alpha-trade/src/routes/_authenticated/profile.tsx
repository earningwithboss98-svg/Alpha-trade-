import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "sonner";
import { Camera, Download, LogOut, QrCode, Share2, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, BottomNav, Logo, TopBar } from "@/components/brand";
import { CopyButton } from "@/components/modals";
import { avatarDataUrl } from "@/lib/image";
import { errMsg, useAppName, useIsAdmin, useProfile, useWallet } from "@/lib/app-data";
import { canInstall, isStandalone, onInstallChange, promptInstall } from "@/lib/pwa";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Profile — Alpha Trade" },
      { name: "description", content: "Your profile, referral link and app install." },
      { property: "og:title", content: "Profile — Alpha Trade" },
      { property: "og:description", content: "Your profile and referral link." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { data: p } = useProfile();
  const { data: w } = useWallet();
  const { data: isAdmin } = useIsAdmin();
  const appName = useAppName();
  const qc = useQueryClient();
  const nav = useNavigate();
  const file = useRef<HTMLInputElement>(null);
  const [name, setName] = useState("");
  const [showQr, setShowQr] = useState(false);
  const [installable, setInstallable] = useState(false);
  const [help, setHelp] = useState(false);

  useEffect(() => { if (p) setName(p.name); }, [p]);
  useEffect(() => { setInstallable(canInstall()); const off = onInstallChange(() => setInstallable(canInstall())); return () => { off(); }; }, []);

  const link = p ? `${typeof window !== "undefined" ? window.location.origin : ""}/ref/${p.referral_code}` : "";

  const save = async (patch: { name?: string; avatar_url?: string }) => {
    const { error } = await supabase.from("profiles").update(patch).eq("id", p!.id);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Saved");
    qc.invalidateQueries({ queryKey: ["profile"] });
  };

  const onPhoto = async (f?: File) => {
    if (!f) return;
    try { await save({ avatar_url: await avatarDataUrl(f) }); } catch { toast.error("Could not read that photo"); }
  };

  const install = async () => {
    if (isStandalone()) { toast.success("App is already installed"); return; }
    const r = await promptInstall();
    if (r === "unavailable") setHelp(true);
    else if (r === "accepted") toast.success("Installing…");
  };

  const share = async () => {
    if (navigator.share) await navigator.share({ title: appName, text: `Join me on ${appName}`, url: link }).catch(() => {});
    else { await navigator.clipboard.writeText(link); toast.success("Link copied"); }
  };

  const signOut = async () => {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    nav({ to: "/auth", search: {}, replace: true });
  };

  return (
    <div className="page">
      <TopBar />
      <section className="glass-card flex flex-col items-center p-6 text-center">
        <button className="relative" onClick={() => file.current?.click()} aria-label="Change photo">
          <Avatar url={p?.avatar_url} name={p?.name} size={96} />
          <span className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground"><Camera className="h-4 w-4" /></span>
        </button>
        <input ref={file} type="file" accept="image/*" hidden onChange={(e) => onPhoto(e.target.files?.[0])} />
        <div className="mt-2 text-sm text-muted-foreground">{p?.email}</div>
        <div className="mt-1 flex gap-2">
          <span className={`chip ${w?.is_paid ? "chip-up" : "chip-muted"}`}>{w?.is_paid ? "Paid investor" : "Not funded yet"}</span>
        </div>
        <div className="mt-4 flex w-full gap-2">
          <input className="field" value={name} maxLength={60} onChange={(e) => setName(e.target.value)} aria-label="Name" />
          <button className="btn-primary px-4" onClick={() => save({ name })}>Save</button>
        </div>
      </section>

      <section className="glass-card mt-4 p-5">
        <h2 className="font-semibold">Referral Link</h2>
        <div className="mt-3 flex items-center gap-2 rounded-xl bg-muted/60 p-3 font-mono text-sm"><span className="flex-1 truncate">{link}</span></div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <CopyButton text={link} className="btn-outline px-2 py-2 text-sm" />
          <button className="btn-outline px-2 py-2 text-sm" onClick={share}><Share2 className="h-4 w-4" /> Share</button>
          <button className="btn-outline px-2 py-2 text-sm" onClick={() => setShowQr((s) => !s)}><QrCode className="h-4 w-4" /> QR</button>
        </div>
        {showQr && <div className="mx-auto mt-3 w-fit rounded-xl bg-foreground p-2"><QRCodeSVG value={link} size={110} /></div>}
      </section>

      <section className="glass-card mt-4 flex items-center gap-4 p-5">
        <Logo size={56} />
        <div className="flex-1"><h2 className="font-semibold">{appName} App</h2><p className="text-xs text-muted-foreground">Install on your phone home screen</p></div>
        <button className="btn-primary px-4 py-2.5 text-sm" onClick={install}><Download className="h-4 w-4" /> {installable ? "Install App" : "Download APK"}</button>
      </section>

      {isAdmin && <Link to="/admin" className="btn-outline mt-4 w-full"><ShieldCheck className="h-5 w-5" /> Admin Panel</Link>}
      <button className="btn-outline mt-3 w-full border-destructive text-down" onClick={signOut}><LogOut className="h-5 w-5" /> Sign out</button>

      {help && (
        <div className="modal-backdrop" onClick={() => setHelp(false)}>
          <div className="modal-card text-left" onClick={(e) => e.stopPropagation()}>
            <Logo size={56} className="mx-auto" />
            <h3 className="mt-3 text-center text-lg font-bold">Install {appName}</h3>
            <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
              <li><b className="text-foreground">Android (Chrome):</b> tap ⋮ menu → "Install app" or "Add to Home screen".</li>
              <li><b className="text-foreground">iPhone (Safari):</b> tap Share → "Add to Home Screen".</li>
              <li>Open {appName} from the new icon on your home screen.</li>
            </ol>
            <button className="btn-primary mt-5 w-full" onClick={() => setHelp(false)}>Got it</button>
          </div>
        </div>
      )}
      <BottomNav />
    </div>
  );
}
