import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, Camera, CheckCircle2, Copy, QrCode } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { BottomNav } from "@/components/brand";
import { QrModal } from "@/components/modals";
import { errMsg, useSettings, useUserId } from "@/lib/app-data";

export const Route = createFileRoute("/_authenticated/deposit")({
  head: () => ({
    meta: [
      { title: "Deposit USDT (BEP20) — Alpha Trade" },
      { name: "description", content: "Deposit USDT on BNB Smart Chain to your Alpha Trade balance." },
      { property: "og:title", content: "Deposit USDT — Alpha Trade" },
      { property: "og:description", content: "Deposit USDT (BEP20) to your balance." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Deposit,
});

function Deposit() {
  const { data: s } = useSettings();
  const uid = useUserId();
  const qc = useQueryClient();
  useEffect(() => {
    qc.invalidateQueries({ queryKey: ["settings"] });
    const t = setInterval(() => qc.invalidateQueries({ queryKey: ["settings"] }), 15000);
    return () => clearInterval(t);
  }, [qc]);
  const copyAddr = async () => {
    if (!s?.bep20_address) return;
    await navigator.clipboard.writeText(s.bep20_address);
    toast.success("Address Copied!");
  };
  const nav = useNavigate();
  const [amount, setAmount] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [qr, setQr] = useState(false);
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const min = Number(s?.min_deposit ?? 5), max = Number(s?.max_deposit ?? 5000);
  const n = Number(amount);
  const amountErr = amount && (n < min ? `Minimum deposit is ${min} USDT` : n > max ? `Maximum deposit is ${max} USDT` : "");

  const submit = async () => {
    if (!n || amountErr) { toast.error(amountErr || "Enter an amount"); return; }
    if (!file) { toast.error("Upload your payment screenshot"); return; }
    if (!uid) return;
    setBusy(true);
    try {
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "");
      const path = `${uid}/${crypto.randomUUID()}.${ext}`;
      const up = await supabase.storage.from("deposit-proofs").upload(path, file, { contentType: file.type });
      if (up.error) throw up.error;
      const { error } = await supabase.rpc("create_deposit", { _amount: n, _screenshot: path });
      if (error) throw error;
      toast.success("Deposit submitted — pending review");
      qc.invalidateQueries();
      nav({ to: "/wallet" });
    } catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };

  return (
    <div className="page pt-5">
      <Link to="/dashboard" className="mb-4 inline-flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Back</Link>
      <h1 className="text-2xl font-bold">Deposit USDT (BEP20)</h1>
      <div className="glass-card mt-5 space-y-5 p-5">
        <div className="rounded-xl border border-border bg-muted/40 p-4">
          <p className="label">Your BEP20 Deposit Address</p>
          {s?.bep20_address ? (
            <>
              <button type="button" className="w-full break-all text-left font-mono text-sm" onClick={copyAddr}>{s.bep20_address}</button>
              <button type="button" className="btn-primary mt-3 w-full py-2.5 text-sm" onClick={copyAddr}><Copy className="h-4 w-4" /> Copy Address</button>
              <p className="mt-2 text-[11px] text-muted-foreground">Tap to copy - Send only USDT BEP20</p>
            </>
          ) : (
            <p className="text-sm text-muted-foreground">Deposit address is being updated. Please check back shortly.</p>
          )}
        </div>
        <p className="text-xs text-muted-foreground">Send only USDT on BNB Smart Chain (BEP20) to the address shown.</p>
        <div>
          <label className="label">How much to deposit?</label>
          <div className="relative">
            <input inputMode="decimal" className="field pr-20 text-3xl font-bold" placeholder="0.00" value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/[^\d.]/g, ""))} />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 font-semibold text-muted-foreground">USDT</span>
          </div>
          <p className={`mt-1.5 text-xs ${amountErr ? "text-down" : "text-muted-foreground"}`}>{amountErr || `Min ${min} · Max ${max} USDT`}</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <button type="button" className={`btn-outline py-2.5 text-sm ${file ? "border-up text-up" : ""}`} onClick={() => input.current?.click()}>
            {file ? <CheckCircle2 className="h-4 w-4" /> : <Camera className="h-4 w-4" />} {file ? "Screenshot added" : "Upload Screenshot"}
          </button>
          <button type="button" className="btn-outline py-2.5 text-sm" onClick={() => setQr(true)}><QrCode className="h-4 w-4" /> Show QR Code</button>
          <input ref={input} type="file" accept="image/*" hidden onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        </div>
        {file && <img src={URL.createObjectURL(file)} alt="Payment screenshot preview" className="max-h-48 w-full rounded-xl object-contain" />}
        <p className="text-xs leading-relaxed text-muted-foreground">{s?.deposit_instructions}</p>
        <button className="btn-primary w-full" disabled={busy} onClick={submit}>{busy ? "Submitting…" : "Verify & Submit"}</button>
      </div>
      {qr && <QrModal address={s?.bep20_address || ""} onClose={() => setQr(false)} />}
      <BottomNav />
    </div>
  );
}
