import { createFileRoute } from "@tanstack/react-router";
import { readPublicSettings } from "@/lib/settings.server";

// Serves the PWA icon generated from the admin-uploaded logo; falls back to the bundled rocket logo icons.
export const Route = createFileRoute("/api/public/icon/$size")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const size = params.size === "512" ? "512" : "192";
        const s = await readPublicSettings();
        const dataUrl = size === "512" ? s?.icon_512_url : s?.icon_192_url;
        const m = dataUrl?.match(/^data:(image\/[a-z+]+);base64,(.+)$/);
        if (m && m[1] && m[2]) {
          const bin = Uint8Array.from(atob(m[2]), (c) => c.charCodeAt(0));
          return new Response(bin, { headers: { "content-type": m[1], "cache-control": "public, max-age=300" } });
        }
        return Response.redirect(new URL(`/icons/icon-${size}.png`, request.url).toString(), 302);
      },
    },
  },
});
