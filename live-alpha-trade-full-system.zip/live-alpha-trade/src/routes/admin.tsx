import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "sonner";
import { ArrowLeft, Check, Eye, Search, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, Logo } from "@/components/brand";
import { StatusChip } from "@/components/TradeRow";
import { squareDataUrl } from "@/lib/image";
import { errMsg, money, useIsAdmin, useSettings, type Settings } from "@/lib/app-data";
import { useServerFn } from "@tanstack/react-start";
import { adminResetPassword } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Panel — Alpha Trade" },
      { name: "description", content: "Manage users, deposits, withdrawals and settings." },
      { property: "og:title", content: "Admin Panel — Alpha Trade" },
      { property: "og:description", content: "Alpha Trade administration." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Admin,
});

const TABS = ["Overview", "Users", "Deposits", "Withdrawals", "Support", "Notify & Bonus", "Settings", "Audit"] as const;

function Admin() {
  const [session, setSession] = useState<boolean | null>(null);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(!!data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(!!s));
    return () => sub.subscription.unsubscribe();
  }, []);
  if (session === null) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;
  if (!session) return <AdminLogin />;
  return <AdminInner />;
}

function AdminLogin() {
  const qc = useQueryClient();
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setErr("");
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pw });
    setBusy(false);
    if (error) { console.error("[admin login]", error); setErr(errMsg(error)); toast.error(errMsg(error)); return; }
    qc.invalidateQueries();
  };
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <form onSubmit={submit} className="glass-card w-full max-w-sm space-y-4 p-6">
        <div className="flex flex-col items-center gap-2"><Logo size={56} /><h1 className="text-xl font-bold">Admin Control Panel</h1></div>
        <div><label className="label">Email</label><input className="field" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><label className="label">Password</label><input className="field" type="password" autoComplete="current-password" required value={pw} onChange={(e) => setPw(e.target.value)} /></div>
        {err && <p className="text-sm text-down">{err}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
      </form>
    </div>
  );
}

function AdminInner() {
  const { data: isAdmin, isPending: isLoading } = useIsAdmin();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Overview");
  if (isLoading) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;
  if (!isAdmin) return <div className="p-10 text-center">Admin access required. <button className="text-primary" onClick={() => supabase.auth.signOut()}>Sign in as admin</button></div>;
  return (
    <div className="mx-auto max-w-6xl px-4 pb-16">
      <header className="flex items-center justify-between py-5">
        <Link to="/profile" className="inline-flex items-center gap-2 text-sm text-muted-foreground"><ArrowLeft className="h-4 w-4" /> Back</Link>
        <div className="flex items-center gap-2"><Logo size={40} /><span className="font-bold">Admin Panel</span></div>
      </header>
      <div className="mb-5 flex gap-2 overflow-x-auto">
        {TABS.map((t) => <button key={t} onClick={() => setTab(t)} className={`chip whitespace-nowrap px-4 py-2 text-sm ${tab === t ? "chip-wait" : "chip-muted"}`}>{t}</button>)}
      </div>
      {tab === "Overview" && <Overview />}
      {tab === "Users" && <Users />}
      {tab === "Deposits" && <Deposits />}
      {tab === "Withdrawals" && <Withdrawals />}
      {tab === "Support" && <SupportTickets />}
      {tab === "Notify & Bonus" && <NotifyBonus />}
      {tab === "Settings" && <SettingsForm />}
      {tab === "Audit" && <Audit />}
    </div>
  );
}

function Overview() {
  const { data } = useQuery({
    queryKey: ["admin-overview"],
    refetchInterval: 30_000,
    queryFn: async () => {
      const [users, deps, wds, tickets] = await Promise.all([
        supabase.from("profiles").select("id", { count: "exact", head: true }),
        supabase.from("deposits").select("amount,status"),
        supabase.from("withdrawals").select("amount,status"),
        supabase.from("support_tickets").select("id,admin_reply"),
      ]);
      const d = deps.data ?? [], w = wds.data ?? [], t = tickets.data ?? [];
      return {
        users: users.count ?? 0,
        deposits: d.filter((x) => x.status === "approved").reduce((s, x) => s + Number(x.amount), 0),
        withdrawals: w.filter((x) => x.status === "approved").reduce((s, x) => s + Number(x.amount), 0),
        pendingDeposits: d.filter((x) => x.status === "pending").length,
        pendingTickets: t.filter((x) => !x.admin_reply).length,
      };
    },
  });
  const cards = [
    ["Total Users", data?.users ?? "—"], ["Total Deposits", data ? money(data.deposits) : "—"],
    ["Total Withdrawals", data ? money(data.withdrawals) : "—"],
    ["Pending Deposits", data?.pendingDeposits ?? "—"], ["Pending Tickets", data?.pendingTickets ?? "—"],
  ] as const;
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
      {cards.map(([label, v]) => (
        <div key={label} className="glass-card p-4 text-center">
          <div className="text-2xl font-extrabold text-primary">{v}</div>
          <div className="text-xs text-muted-foreground">{label}</div>
        </div>
      ))}
    </div>
  );
}

function SupportTickets() {
  const qc = useQueryClient();
  const { data: names } = useNames();
  const [sel, setSel] = useState<string | null>(null);
  const [reply, setReply] = useState("");
  const [img, setImg] = useState<string | null>(null);
  const { data = [] } = useQuery({
    queryKey: ["admin-support-msgs"],
    refetchInterval: 20_000,
    queryFn: async () => {
      const since = new Date(Date.now() - 24 * 3600_000).toISOString();
      return (await supabase.from("support_messages").select("*").gt("created_at", since).order("created_at", { ascending: true }).limit(500)).data ?? [];
    },
  });
  const convos = new Map<string, typeof data>();
  for (const m of data) convos.set(m.user_id, [...(convos.get(m.user_id) ?? []), m]);
  const list = [...convos.entries()].sort((a, b) => (b[1].at(-1)!.created_at > a[1].at(-1)!.created_at ? 1 : -1));
  const view = async (path: string) => {
    const { data, error } = await supabase.storage.from("support-images").createSignedUrl(path, 300);
    if (error) { toast.error(errMsg(error)); return; }
    setImg(data.signedUrl);
  };
  const send = async () => {
    const text = reply.trim();
    if (!sel || !text) return;
    const { error } = await supabase.from("support_messages").insert({ user_id: sel, sender: "admin", body: text });
    if (error) { toast.error(errMsg(error)); return; }
    setReply("");
    qc.invalidateQueries({ queryKey: ["admin-support-msgs"] });
  };
  const msgs = sel ? convos.get(sel) ?? [] : [];
  return (
    <div className="grid gap-3 md:grid-cols-[260px_1fr]">
      <div className="glass-card divide-y divide-border">
        {list.length ? list.map(([u, ms]) => {
          const last = ms.at(-1)!;
          const waiting = last.sender !== "admin";
          return (
            <button key={u} onClick={() => setSel(u)} className={`block w-full p-3 text-left text-sm ${sel === u ? "bg-muted" : ""}`}>
              <div className="flex items-center justify-between gap-2"><span className="truncate font-semibold">{names?.get(u)?.name ?? "User"}</span>{waiting && <span className="chip chip-wait">Open</span>}</div>
              <div className="truncate text-xs text-muted-foreground">{names?.get(u)?.email}</div>
              <div className="truncate text-xs text-muted-foreground">{last.body || "Image"}</div>
            </button>
          );
        }) : <p className="p-6 text-center text-sm text-muted-foreground">No chats in the last 24 hours</p>}
      </div>
      <div className="glass-card p-4">
        {!sel ? <p className="text-center text-sm text-muted-foreground">Select a chat</p> : (<>
          <div className="max-h-[60vh] space-y-2 overflow-y-auto">
            {msgs.map((m) => (
              <div key={m.id} className={`flex ${m.sender === "user" ? "justify-start" : "justify-end"}`}>
                <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${m.sender === "user" ? "bg-muted" : "bg-primary text-primary-foreground"}`}>
                  {m.category && <div className="text-[10px] font-bold opacity-70">{m.category}</div>}
                  {m.body && <p className="whitespace-pre-wrap">{m.body}</p>}
                  {m.image_path && <button className="mt-1 inline-flex items-center gap-1 text-xs underline" onClick={() => view(m.image_path!)}><Eye className="h-3 w-3" /> View image</button>}
                  <div className="text-right text-[10px] opacity-60">{new Date(m.created_at).toLocaleTimeString()}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-2">
            <input className="field py-2" placeholder="Write a reply…" value={reply} onChange={(e) => setReply(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") send(); }} />
            <button className="btn-primary px-4 py-2 text-sm" onClick={send}>Reply</button>
          </div>
        </>)}
      </div>
      {img && <div className="modal-backdrop" onClick={() => setImg(null)}><img src={img} alt="Attachment" className="max-h-[85vh] max-w-full rounded-xl" /></div>}
    </div>
  );
}

function ResetPassword({ userId }: { userId: string }) {
  const reset = useServerFn(adminResetPassword);
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const go = async () => {
    if (pw.length < 8) { toast.error("Password must be at least 8 characters"); return; }
    setBusy(true);
    try { await reset({ data: { userId, password: pw } }); toast.success("Password updated"); setPw(""); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };
  const gen = () => setPw(Array.from(crypto.getRandomValues(new Uint8Array(9)), (b) => "abcdefghjkmnpqrstuvwxyzACDEFGHJKLMNPQRSTUVWXYZ23456789"[b % 54]).join(""));
  return (
    <div className="mt-4">
      <h4 className="text-sm font-semibold">Reset password</h4>
      <div className="mt-2 flex gap-2">
        <input className="field py-2" placeholder="New password" value={pw} onChange={(e) => setPw(e.target.value)} />
        <button className="btn-outline px-3 py-2 text-xs" onClick={gen}>Generate</button>
      </div>
      <button className="btn-primary mt-2 w-full py-2 text-sm" disabled={busy} onClick={go}>{busy ? "Updating…" : "Reset Password"}</button>
    </div>
  );
}

function Users() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [f, setF] = useState<"all" | "paid" | "unfunded" | "blocked">("all");
  const [view, setView] = useState<string | null>(null);
  const { data } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async () => {
      const [p, w, t] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at", { ascending: false }),
        supabase.from("wallets").select("*"),
        supabase.from("trades").select("user_id").eq("status", "open"),
      ]);
      const wm = new Map((w.data ?? []).map((x) => [x.user_id, x]));
      const trading = new Set((t.data ?? []).map((x) => x.user_id));
      return (p.data ?? []).map((u) => ({ ...u, wallet: wm.get(u.id), trading: trading.has(u.id) }));
    },
  });
  const list = (data ?? []).filter((u) =>
    (!q || `${u.name} ${u.email}`.toLowerCase().includes(q.toLowerCase())) &&
    (f === "all" || (f === "paid" && u.wallet?.is_paid) || (f === "unfunded" && !u.wallet?.is_paid) || (f === "blocked" && u.blocked)));
  const toggle = async (id: string, blocked: boolean) => {
    const { error } = await supabase.rpc("set_user_blocked", { _user: id, _blocked: blocked });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(blocked ? "User blocked" : "User unblocked");
    qc.invalidateQueries({ queryKey: ["admin-users"] });
  };
  const sel = data?.find((u) => u.id === view);
  return (
    <div className="glass-card p-4">
      <div className="mb-3 flex flex-wrap gap-2">
        <div className="relative flex-1"><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><input className="field py-2 pl-9" placeholder="Search name or email" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <select className="field w-auto py-2" value={f} onChange={(e) => setF(e.target.value as typeof f)}>
          <option value="all">All</option><option value="paid">Paid</option><option value="unfunded">Unfunded</option><option value="blocked">Blocked</option>
        </select>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-xs uppercase text-muted-foreground"><tr>
            <th className="p-2"></th><th className="p-2">Name</th><th className="p-2">Email</th><th className="p-2">Status</th><th className="p-2">Trading</th><th className="p-2">Investor</th><th className="p-2 text-right">Balance</th><th className="p-2">Block</th><th className="p-2"></th>
          </tr></thead>
          <tbody>
            {list.map((u) => (
              <tr key={u.id} className="border-t border-border">
                <td className="p-2"><Avatar url={u.avatar_url} size={32} /></td>
                <td className="p-2 font-medium">{u.name}</td>
                <td className="p-2 text-muted-foreground">{u.email}</td>
                <td className="p-2"><span className={`chip ${u.blocked ? "chip-down" : "chip-up"}`}>{u.blocked ? "Blocked" : "Active"}</span></td>
                <td className="p-2"><span className={`chip ${u.trading ? "chip-wait" : "chip-muted"}`}>{u.trading ? "Trading" : "Not Trading"}</span></td>
                <td className="p-2"><span className={`chip ${u.wallet?.is_paid ? "chip-up" : "chip-muted"}`}>{u.wallet?.is_paid ? "Paid" : "Unfunded"}</span></td>
                <td className="p-2 text-right font-semibold">{money(u.wallet?.balance)}</td>
                <td className="p-2"><input type="checkbox" className="h-5 w-5 accent-[var(--down)]" checked={u.blocked} onChange={(e) => toggle(u.id, e.target.checked)} aria-label="Block user" /></td>
                <td className="p-2"><button className="rounded-lg p-1.5 hover:bg-muted" onClick={() => setView(u.id)} aria-label="View"><Eye className="h-4 w-4" /></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {sel && <UserDetail u={sel} onClose={() => setView(null)} />}
    </div>
  );
}

function UserDetail({ u, onClose }: { u: { id: string; name: string; email: string | null; avatar_url: string | null; referral_code: string; referred_by: string | null; created_at: string }; onClose: () => void }) {
  const { data } = useQuery({
    queryKey: ["admin-user-trades", u.id],
    queryFn: async () => (await supabase.from("trades").select("*").eq("user_id", u.id).order("opened_at", { ascending: false }).limit(15)).data ?? [],
  });
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card max-w-md text-left" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-3"><Avatar url={u.avatar_url} size={48} /><div><div className="font-bold">{u.name}</div><div className="text-xs text-muted-foreground">{u.email}</div></div></div>
        <div className="mt-3 text-xs text-muted-foreground">Joined {new Date(u.created_at).toLocaleDateString()} · Code {u.referral_code}{u.referred_by ? ` · Referred by ${u.referred_by}` : ""}</div>
        <h4 className="mt-4 text-sm font-semibold">Recent trades</h4>
        <div className="mt-2 max-h-60 space-y-1 overflow-y-auto text-sm">
          {data?.length ? data.map((t) => <div key={t.id} className="flex justify-between"><span>{t.side.toUpperCase()} {money(t.amount)} · {t.duration_seconds}s</span><span className="capitalize">{t.status}</span></div>) : <p className="text-muted-foreground">No trades</p>}
        </div>
        <button className="btn-primary mt-5 w-full" onClick={onClose}>Close</button>
      </div>
    </div>
  );
}

function useNames() {
  return useQuery({
    queryKey: ["admin-names"],
    queryFn: async () => new Map(((await supabase.from("profiles").select("id,name,email")).data ?? []).map((p) => [p.id, p])),
  });
}

function Deposits() {
  const qc = useQueryClient();
  const { data: names } = useNames();
  const { data: s } = useSettings();
  const [shot, setShot] = useState<string | null>(null);
  const { data } = useQuery({
    queryKey: ["admin-deposits"],
    queryFn: async () => (await supabase.from("deposits").select("*").order("created_at", { ascending: false }).limit(100)).data ?? [],
  });
  const review = async (id: string, approve: boolean) => {
    const { error } = await supabase.rpc("review_deposit", { _id: id, _approve: approve });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(approve ? "Deposit approved — balance credited" : "Deposit rejected");
    qc.invalidateQueries();
  };
  const view = async (path: string) => {
    const { data, error } = await supabase.storage.from("deposit-proofs").createSignedUrl(path, 300);
    if (error) { toast.error(errMsg(error)); return; }
    setShot(data.signedUrl);
  };
  return (
    <div className="glass-card divide-y divide-border">
      {data?.length ? data.map((d) => {
        const outOfLimits = s && (Number(d.amount) < Number(s.min_deposit) || Number(d.amount) > Number(s.max_deposit));
        return (
          <div key={d.id} className="flex flex-wrap items-center gap-3 p-4">
            <div className="flex-1">
              <div className="font-semibold">{money(d.amount)} <span className="text-xs text-muted-foreground">· {names?.get(d.user_id)?.name} ({names?.get(d.user_id)?.email})</span></div>
              <div className="text-xs text-muted-foreground">{new Date(d.created_at).toLocaleString()} {outOfLimits && <span className="text-down">· outside current limits</span>}</div>
            </div>
            <button className="btn-outline px-3 py-1.5 text-sm" onClick={() => view(d.screenshot_path)}><Eye className="h-4 w-4" /> Screenshot</button>
            {d.status === "pending" ? (
              <>
                <button className="btn-up px-3 py-1.5 text-sm" onClick={() => review(d.id, true)}><Check className="h-4 w-4" /> Approve</button>
                <button className="btn-down px-3 py-1.5 text-sm" onClick={() => review(d.id, false)}><X className="h-4 w-4" /> Reject</button>
              </>
            ) : <StatusChip s={d.status} />}
          </div>
        );
      }) : <p className="p-6 text-center text-sm text-muted-foreground">No deposits</p>}
      {shot && <div className="modal-backdrop" onClick={() => setShot(null)}><img src={shot} alt="Deposit proof" className="max-h-[85vh] max-w-full rounded-xl" /></div>}
    </div>
  );
}

function Withdrawals() {
  const qc = useQueryClient();
  const { data: names } = useNames();
  const { data } = useQuery({
    queryKey: ["admin-withdrawals"],
    queryFn: async () => (await supabase.from("withdrawals").select("*").order("created_at", { ascending: false }).limit(100)).data ?? [],
  });
  const review = async (id: string, approve: boolean) => {
    const { error } = await supabase.rpc("review_withdrawal", { _id: id, _approve: approve });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(approve ? "Marked as paid" : "Rejected — amount returned to user");
    qc.invalidateQueries();
  };
  return (
    <div className="glass-card divide-y divide-border">
      {data?.length ? data.map((w) => (
        <div key={w.id} className="flex flex-wrap items-center gap-3 p-4">
          <div className="min-w-0 flex-1">
            <div className="font-semibold">{money(w.amount)} <span className="text-xs text-muted-foreground">fee {money(w.fee)} · send {money(Number(w.amount) - Number(w.fee))} · {names?.get(w.user_id)?.name}</span></div>
            <div className="truncate font-mono text-xs text-muted-foreground">{w.address}</div>
            <div className="text-xs text-muted-foreground">{new Date(w.created_at).toLocaleString()}</div>
          </div>
          {w.status === "pending" ? (
            <>
              <button className="btn-up px-3 py-1.5 text-sm" onClick={() => review(w.id, true)}><Check className="h-4 w-4" /> Approve</button>
              <button className="btn-down px-3 py-1.5 text-sm" onClick={() => review(w.id, false)}><X className="h-4 w-4" /> Reject</button>
            </>
          ) : <StatusChip s={w.status} />}
        </div>
      )) : <p className="p-6 text-center text-sm text-muted-foreground">No withdrawals</p>}
    </div>
  );
}

const TZS = ["UTC", "Asia/Karachi", "Asia/Dubai", "Asia/Kolkata", "Europe/London", "America/New_York", "Asia/Singapore"];
const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function SettingsForm() {
  const { data } = useSettings();
  const qc = useQueryClient();
  const [s, setS] = useState<Settings | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (data) setS(data); }, [data]);
  if (!s) return null;
  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => setS({ ...s, [k]: v });
  const num = (k: keyof Settings, label: string) => (
    <div><label className="label">{label}</label><input className="field" inputMode="decimal" value={String(s[k] ?? "")} onChange={(e) => set(k, e.target.value as never)} /></div>
  );

  const onLogo = async (f?: File) => {
    if (!f) return;
    try {
      const [logo, i192, i512] = await Promise.all([
        squareDataUrl(f, 256),
        squareDataUrl(f, 192, { pad: 0.12, bg: "#07070b" }),
        squareDataUrl(f, 512, { pad: 0.12, bg: "#07070b" }),
      ]);
      setS({ ...s, logo_url: logo, icon_192_url: i192, icon_512_url: i512 });
      toast.success("Logo ready — click Save Settings to apply everywhere");
    } catch { toast.error("Could not read that image"); }
  };

  const save = async () => {
    if (s.bep20_address && !/^0x[a-fA-F0-9]{40}$/.test(s.bep20_address.trim())) { toast.error("BEP20 address must look like 0x + 40 characters"); return; }
    setBusy(true);
    const { id: _id, ...rest } = s;
    const numeric = ["min_deposit", "max_deposit", "min_withdraw", "max_withdraw", "withdraw_fee_percent", "withdraw_fee_fixed", "auto_approve_limit", "profit_percent", "min_trade", "max_trade"] as const;
    const patch: Record<string, unknown> = { ...rest, bep20_address: s.bep20_address.trim(), updated_at: new Date().toISOString() };
    numeric.forEach((k) => (patch[k] = Number(s[k]) || 0));
    const { error } = await supabase.from("settings").update(patch as never).eq("id", 1);
    setBusy(false);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Settings saved");
    qc.invalidateQueries({ queryKey: ["settings"] });
  };

  return (
    <div className="space-y-4">
      <section className="glass-card grid gap-4 p-5 md:grid-cols-2">
        <div><label className="label">App Name</label><input className="field" value={s.app_name} onChange={(e) => set("app_name", e.target.value)} /></div>
        <div>
          <label className="label">Logo Upload</label>
          <div className="flex items-center gap-3">
            <img src={s.logo_url || "/logo.png"} alt="Logo" className="h-14 w-14 rounded-xl object-contain" />
            {s.icon_192_url && <img src={s.icon_192_url} alt="App icon" className="h-14 w-14 rounded-2xl" />}
            <input type="file" accept="image/*" onChange={(e) => onLogo(e.target.files?.[0])} className="text-xs" />
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground">Updates header, sign-in, favicon and app icons (192 & 512). Installed apps pick up the new icon after reinstall.</p>
        </div>
      </section>

      <section className="glass-card grid gap-4 p-5 md:grid-cols-[1fr_auto]">
        <div>
          <label className="label">USDT BEP20 Deposit Address</label>
          <input className="field font-mono text-sm" placeholder="0x…" value={s.bep20_address} onChange={(e) => set("bep20_address", e.target.value)} />
          <label className="label mt-4">Deposit Instructions</label>
          <textarea className="field" rows={2} value={s.deposit_instructions} onChange={(e) => set("deposit_instructions", e.target.value)} />
        </div>
        {s.bep20_address && <div className="rounded-xl bg-foreground p-2"><QRCodeSVG value={s.bep20_address} size={120} /></div>}
      </section>

      <section className="glass-card grid grid-cols-2 gap-4 p-5 md:grid-cols-4">
        {num("min_deposit", "Min Deposit")}{num("max_deposit", "Max Deposit")}{num("min_withdraw", "Min Withdraw")}{num("max_withdraw", "Max Withdraw")}
        {num("withdraw_fee_percent", "Withdraw Fee %")}{num("withdraw_fee_fixed", "Withdraw Fee $")}{num("auto_approve_limit", "Auto-approve deposits ≤ (0 = off)")}{num("profit_percent", "Trading Profit %")}
        {num("min_trade", "Min Trade")}{num("max_trade", "Max Trade")}
      </section>

      <section className="glass-card grid gap-4 p-5 md:grid-cols-3">
        <div><label className="label">Withdraw Start</label><input type="time" className="field" value={s.withdraw_start.slice(0, 5)} onChange={(e) => set("withdraw_start", e.target.value)} /></div>
        <div><label className="label">Withdraw End</label><input type="time" className="field" value={s.withdraw_end.slice(0, 5)} onChange={(e) => set("withdraw_end", e.target.value)} /></div>
        <div><label className="label">Timezone</label><select className="field" value={s.withdraw_timezone} onChange={(e) => set("withdraw_timezone", e.target.value)}>{TZS.map((t) => <option key={t}>{t}</option>)}</select></div>
        <div className="md:col-span-3">
          <label className="label">Withdraw Days</label>
          <div className="flex flex-wrap gap-3">
            {DAYS.map((d, i) => (
              <label key={d} className="flex items-center gap-1.5 text-sm">
                <input type="checkbox" className="accent-[var(--primary)]" checked={s.withdraw_days.includes(i + 1)}
                  onChange={(e) => set("withdraw_days", e.target.checked ? [...s.withdraw_days, i + 1].sort() : s.withdraw_days.filter((x) => x !== i + 1))} />{d}
              </label>
            ))}
          </div>
        </div>
        <div className="md:col-span-3"><label className="label">Withdraw Instructions</label><textarea className="field" rows={2} value={s.withdraw_instructions} onChange={(e) => set("withdraw_instructions", e.target.value)} /></div>
      </section>

      <button className="btn-primary w-full md:w-auto md:px-10" disabled={busy} onClick={save}>{busy ? "Saving…" : "Save Settings"}</button>
    </div>
  );
}

function Audit() {
  const { data: names } = useNames();
  const { data } = useQuery({
    queryKey: ["admin-audit"],
    queryFn: async () => (await supabase.from("audit_log").select("*").order("created_at", { ascending: false }).limit(200)).data ?? [],
  });
  return (
    <div className="glass-card divide-y divide-border text-sm">
      {data?.length ? data.map((a) => (
        <div key={a.id} className="flex flex-wrap gap-2 p-3">
          <span className="font-mono text-xs text-muted-foreground">{new Date(a.created_at).toLocaleString()}</span>
          <span className="chip chip-wait">{a.action}</span>
          <span>{a.actor ? names?.get(a.actor)?.email : "system"}</span>
          <span className="text-muted-foreground">{a.detail}</span>
        </div>
      )) : <p className="p-6 text-center text-muted-foreground">No entries</p>}
    </div>
  );
}

function NotifyBonus() {
  const { data: s } = useSettings();
  const qc = useQueryClient();
  const [n, setN] = useState({ email: "", title: "", message: "" });
  const [b, setB] = useState({ email: "", amount: "", reason: "Trading bonus" });
  const [ref, setRef] = useState<string>("");
  useEffect(() => { if (s) setRef(String(s.referral_bonus ?? 5)); }, [s]);
  const send = async () => {
    const { error } = await supabase.rpc("admin_send_notification", { _email: n.email, _title: n.title, _message: n.message });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success(n.email ? "Sent to user" : "Broadcast sent to all users"); setN({ email: "", title: "", message: "" });
  };
  const give = async () => {
    const { error } = await supabase.rpc("admin_give_bonus", { _email: b.email, _amount: Number(b.amount), _reason: b.reason });
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Bonus credited — user has 24h to claim"); setB({ ...b, email: "", amount: "" });
  };
  const saveRef = async () => {
    const { error } = await supabase.from("settings").update({ referral_bonus: Number(ref) }).eq("id", 1);
    if (error) { toast.error(errMsg(error)); return; }
    toast.success("Referral bonus saved"); qc.invalidateQueries({ queryKey: ["settings"] });
  };
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <section className="glass-card space-y-3 p-5">
        <h3 className="font-bold">Send Notification</h3>
        <input className="field" placeholder="User email or ID (leave empty = all users)" value={n.email} onChange={(e) => setN({ ...n, email: e.target.value })} />
        <input className="field" placeholder="Title" value={n.title} onChange={(e) => setN({ ...n, title: e.target.value })} />
        <textarea className="field min-h-24" placeholder="Message" value={n.message} onChange={(e) => setN({ ...n, message: e.target.value })} />
        <button className="btn-primary w-full" onClick={send}>{n.email ? "Send to user" : "Broadcast to all"}</button>
      </section>
      <section className="glass-card space-y-3 p-5">
        <h3 className="font-bold">Give Bonus (24h to claim)</h3>
        <input className="field" placeholder="User email or ID" value={b.email} onChange={(e) => setB({ ...b, email: e.target.value })} />
        <input className="field" inputMode="decimal" placeholder="Amount USDT" value={b.amount} onChange={(e) => setB({ ...b, amount: e.target.value })} />
        <input className="field" placeholder="Reason" value={b.reason} onChange={(e) => setB({ ...b, reason: e.target.value })} />
        <button className="btn-primary w-full" onClick={give}>Credit Bonus</button>
        <div className="border-t pt-3">
          <label className="label">Referral bonus amount (USDT)</label>
          <div className="flex gap-2"><input className="field" inputMode="decimal" value={ref} onChange={(e) => setRef(e.target.value)} /><button className="btn-outline" onClick={saveRef}>Save</button></div>
        </div>
      </section>
      <SentNotifications />
    </div>
  );
}

function SentNotifications() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin-notifications"],
    queryFn: async () => (await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(50)).data ?? [],
    refetchInterval: 15_000,
  });
  const del = async (id: string) => {
    const { error } = await supabase.from("notifications").delete().eq("id", id);
    if (error) { toast.error(errMsg(error)); return; }
    qc.invalidateQueries({ queryKey: ["admin-notifications"] });
  };
  return (
    <section className="glass-card p-5 md:col-span-2">
      <h3 className="mb-2 font-bold">Sent notifications</h3>
      <ul className="divide-y divide-border">
        {(data ?? []).map((n) => (
          <li key={n.id} className="flex items-start justify-between gap-3 py-2 text-sm">
            <div className="min-w-0">
              <div className="font-semibold">{n.title} <span className="chip chip-wait">{n.user_id ? (n.target_email ?? "User") : "All"}</span></div>
              <div className="text-muted-foreground">{n.message}</div>
            </div>
            <button className="btn-outline px-3 py-1 text-xs" onClick={() => del(n.id)}>Delete</button>
          </li>
        ))}
        {!data?.length && <li className="py-4 text-center text-muted-foreground">Nothing sent yet</li>}
      </ul>
    </section>
  );
}
