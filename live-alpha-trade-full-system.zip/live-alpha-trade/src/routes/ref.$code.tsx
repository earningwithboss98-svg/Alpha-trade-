import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/ref/$code")({
  head: () => ({
    meta: [
      { title: "You're invited — Alpha Trade" },
      { name: "description", content: "Join Alpha Trade and trade BTC/USDT live." },
      { property: "og:title", content: "You're invited to Alpha Trade" },
      { property: "og:description", content: "Join Alpha Trade and trade BTC/USDT live." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Ref,
});

function Ref() {
  const { code } = Route.useParams();
  const nav = useNavigate();
  useEffect(() => {
    if (/^[A-Za-z0-9]{6}$/.test(code)) localStorage.setItem("at_ref", code.toUpperCase());
    nav({ to: "/auth", search: { mode: "register" }, replace: true });
  }, [code, nav]);
  return null;
}
