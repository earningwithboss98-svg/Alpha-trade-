function loadImage(file: File | string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = typeof file === "string" ? file : URL.createObjectURL(file);
  });
}

/** Draw an image centered into a square canvas, with padding and optional background. */
export async function squareDataUrl(
  file: File | string, size: number, opts: { pad?: number; bg?: string; type?: string; quality?: number } = {},
) {
  const img = await loadImage(file);
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  if (opts.bg) { ctx.fillStyle = opts.bg; ctx.fillRect(0, 0, size, size); }
  const pad = (opts.pad ?? 0) * size;
  const box = size - pad * 2;
  const scale = Math.min(box / img.width, box / img.height);
  const w = img.width * scale, h = img.height * scale;
  ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
  return c.toDataURL(opts.type ?? "image/png", opts.quality ?? 0.9);
}

/** Cover-crop for avatars. */
export async function avatarDataUrl(file: File, size = 160) {
  const img = await loadImage(file);
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  const s = Math.min(img.width, img.height);
  ctx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
  return c.toDataURL("image/jpeg", 0.85);
}
