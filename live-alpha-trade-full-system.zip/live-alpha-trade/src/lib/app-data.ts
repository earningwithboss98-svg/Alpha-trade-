import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Settings = Tables<"settings">;
export const DEFAULT_LOGO = "/logo.png";

export function useSettings() {
  return useQuery({
    queryKey: ["settings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("settings").select("*").eq("id", 1).single();
      if (error) throw error;
      return data as Settings;
    },
    staleTime: 60_000,
  });
}

export function useLogo() {
  const { data } = useSettings();
  return data?.logo_url || DEFAULT_LOGO;
}

export function useAppName() {
  const { data } = useSettings();
  return data?.app_name || "Alpha Trade";
}

// Shared, locally-read session id: avoids a network round-trip on every page open.
let cachedUid: string | null = null;
const uidListeners = new Set<(id: string | null) => void>();
let uidInit = false;
function initUid() {
  if (uidInit || typeof window === "undefined") return;
  uidInit = true;
  supabase.auth.getSession().then(({ data }) => setCached(data.session?.user.id ?? null));
  supabase.auth.onAuthStateChange((_e, s) => setCached(s?.user.id ?? null));
}
function setCached(id: string | null) {
  if (id === cachedUid) return;
  cachedUid = id;
  uidListeners.forEach((l) => l(id));
}

export function useUserId() {
  const [uid, setUid] = useState<string | null>(cachedUid);
  useEffect(() => {
    initUid();
    setUid(cachedUid);
    uidListeners.add(setUid);
    return () => { uidListeners.delete(setUid); };
  }, []);
  return uid;
}

export function useProfile() {
  const uid = useUserId();
  return useQuery({
    queryKey: ["profile", uid],
    enabled: !!uid,
    queryFn: async () => {
      if (!uid) throw new Error("Sign in required");
      const { data, error } = await supabase.from("profiles").select("*").eq("id", uid).single();
      if (error) throw error;
      return data;
    },
  });
}

export function useWallet() {
  const uid = useUserId();
  return useQuery({
    queryKey: ["wallet", uid],
    enabled: !!uid,
    queryFn: async () => {
      if (!uid) throw new Error("Sign in required");
      const { data, error } = await supabase.from("wallets").select("*").eq("user_id", uid).single();
      if (error) throw error;
      return data;
    },
  });
}

export function useIsAdmin() {
  const uid = useUserId();
  return useQuery({
    queryKey: ["is-admin", uid],
    enabled: !!uid,
    queryFn: async () => {
      if (!uid) return false;
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", uid).eq("role", "admin");
      return (data?.length ?? 0) > 0;
    },
  });
}

export function useTrades(limit = 30) {
  const uid = useUserId();
  return useQuery({
    queryKey: ["trades", uid, limit],
    enabled: !!uid,
    queryFn: async () => {
      if (!uid) throw new Error("Sign in required");
      const { data, error } = await supabase
        .from("trades").select("*").eq("user_id", uid).order("opened_at", { ascending: false }).limit(limit);
      if (error) throw error;
      return data;
    },
  });
}

export function useRefreshAll() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries();
}

export const money = (n: number | string | null | undefined) =>
  "$" + Number(n ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const DURATIONS = [
  { label: "15s", s: 15 }, { label: "30s", s: 30 }, { label: "60s", s: 60 },
  { label: "120s", s: 120 }, { label: "300s", s: 300 },
];

export const fmtTimer = (sec: number) => {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return [h, m, s].map((x) => String(x).padStart(2, "0")).join(":");
};

export function errMsg(e: unknown) {
  const m = (e as { message?: string })?.message || "Something went wrong";
  return m.replace(/^.*?ERROR:\s*/, "");
}
