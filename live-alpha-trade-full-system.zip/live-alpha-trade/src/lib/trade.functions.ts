import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const HOSTS = ["https://data-api.binance.vision", "https://api.binance.com", "https://api1.binance.com"];

async function binance(path: string) {
  let lastErr: unknown;
  for (const h of HOSTS) {
    try {
      const r = await fetch(h + path, { headers: { accept: "application/json" } });
      if (r.ok) return await r.json();
      lastErr = new Error(`Binance ${r.status}`);
    } catch (e) { lastErr = e; }
  }
  throw lastErr ?? new Error("Market unavailable");
}

async function getJson(url: string) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 2500);
  try {
    const r = await fetch(url, { headers: { accept: "application/json" }, signal: ctl.signal });
    return r.ok ? await r.json() : null;
  } catch { return null; } finally { clearTimeout(t); }
}

async function livePrice(): Promise<number> {
  try {
    const j = await binance("/api/v3/ticker/price?symbol=BTCUSDT");
    const p = Number(j.price);
    if (p) return p;
  } catch { /* fall through */ }
  const sources: [string, (j: any) => unknown][] = [
    ["https://api.coinbase.com/v2/prices/BTC-USD/spot", (j) => j?.data?.amount],
    ["https://www.okx.com/api/v5/market/ticker?instId=BTC-USDT", (j) => j?.data?.[0]?.last],
    ["https://api.kraken.com/0/public/Ticker?pair=XBTUSDT", (j) => (Object.values(j?.result ?? {})[0] as any)?.c?.[0]],
    ["https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd", (j) => j?.bitcoin?.usd],
  ];
  const results = await Promise.all(sources.map(async ([u, pick]) => Number(pick(await getJson(u))) || 0));
  const p = results.find((x) => x > 0);
  if (p) return p;
  throw new Error("Price is updating, please tap again");
}

async function priceAt(ms: number): Promise<number> {
  try {
    const rows = await binance(`/api/v3/klines?symbol=BTCUSDT&interval=1s&startTime=${ms}&limit=1`);
    if (Array.isArray(rows) && rows.length) return Number(rows[0][4]);
  } catch { /* fall through */ }
  return livePrice();
}

export const openTrade = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({
      side: z.enum(["up", "down"]),
      amount: z.number().positive().max(1_000_000),
      duration: z.number().int().refine((v) => [15, 30, 60, 120, 300].includes(v)),
    }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const price = await livePrice();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: t, error } = await supabaseAdmin.rpc("open_trade", {
      _user: context.userId, _side: data.side, _amount: data.amount, _duration: data.duration, _price: price,
    });
    if (error) throw new Error(error.message);
    return t as { id: string; expires_at: string; opened_at: string; open_price: number; amount: number; side: string };
  });

export const settleTrade = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: own } = await context.supabase.from("trades").select("*").eq("id", data.id).single();
    if (!own) throw new Error("Trade not found");
    if (own.status !== "open") return own;
    const exp = new Date(own.expires_at).getTime();
    if (Date.now() < exp) throw new Error("Trade not finished");
    // Settle right at expiry with the same source chain used for the entry price.
    const close = Date.now() - exp < 10_000 ? await livePrice() : await priceAt(exp);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: t, error } = await supabaseAdmin.rpc("settle_trade", { _id: data.id, _close: close });
    if (error) throw new Error(error.message);
    return t as typeof own;
  });

/** Settle any of the caller's open trades that have already expired (e.g. app was closed). */
export const settleExpired = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: open } = await context.supabase
      .from("trades").select("id,expires_at").eq("user_id", context.userId).eq("status", "open")
      .lt("expires_at", new Date().toISOString()).limit(20);
    if (!open?.length) return { settled: 0 };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    for (const t of open) {
      const close = await priceAt(new Date(t.expires_at).getTime());
      await supabaseAdmin.rpc("settle_trade", { _id: t.id, _close: close });
    }
    return { settled: open.length };
  });
