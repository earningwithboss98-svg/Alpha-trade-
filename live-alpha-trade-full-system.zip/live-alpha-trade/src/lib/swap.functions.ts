import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const SWAP_COINS = ["USDT", "BTC", "ETH", "BNB", "SOL", "XRP", "DOGE", "ADA", "SHIB", "PEPE", "LTC", "TRX", "AVAX", "LINK", "DOT"] as const;
const HOSTS = ["https://data-api.binance.vision", "https://api.binance.com", "https://api1.binance.com"];

async function usdPrice(sym: string): Promise<number> {
  if (sym === "USDT") return 1;
  for (const h of HOSTS) {
    try {
      const r = await fetch(`${h}/api/v3/ticker/price?symbol=${sym}USDT`);
      if (r.ok) { const p = Number((await r.json()).price); if (p) return p; }
    } catch { /* next host */ }
  }
  throw new Error("Price unavailable, try again");
}

export const swapCoins = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({
    from: z.enum(SWAP_COINS), to: z.enum(SWAP_COINS), amount: z.number().positive().max(1e12),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const [fp, tp] = await Promise.all([usdPrice(data.from), usdPrice(data.to)]);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.rpc("do_swap", {
      _user: context.userId, _from: data.from, _to: data.to, _amount: data.amount, _from_price: fp, _to_price: tp,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
