export function timeGreeting(hour: number) {
  if (hour >= 5 && hour < 12) return "Good Morning";
  if (hour >= 12 && hour < 17) return "Good Afternoon";
  if (hour >= 17 && hour < 21) return "Good Evening";
  return "Good Night";
}

export function profileGreeting(hour: number, trading: boolean) {
  const greeting = timeGreeting(hour);
  return trading ? `${greeting} - Good trading` : greeting;
}