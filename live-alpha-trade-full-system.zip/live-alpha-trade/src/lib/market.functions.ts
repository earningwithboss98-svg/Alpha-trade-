import { createServerFn } from "@tanstack/react-start";

const HOSTS = ["https://data-api.binance.vision", "https://api.binance.com", "https://api1.binance.com", "https://api2.binance.com"];

async function binance(path: string) {
  let lastErr: unknown;
  for (const h of HOSTS) {
    try {
      const r = await fetch(h + path, { headers: { accept: "application/json" } });
      if (r.ok) return await r.json();
      lastErr = new Error(`Binance ${r.status}`);
    } catch (e) { lastErr = e; }
  }
  throw lastErr ?? new Error("Market unavailable");
}

async function coingeckoPrice(): Promise<number> {
  const r = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd", { headers: { accept: "application/json" } });
  if (!r.ok) throw new Error(`CoinGecko ${r.status}`);
  const j = await r.json();
  const p = Number(j?.bitcoin?.usd);
  if (!p) throw new Error("No price");
  return p;
}

/** Server-side live BTC price with CoinGecko fallback (no browser CORS/403 issues). */
export const marketPrice = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const j = await binance("/api/v3/ticker/price?symbol=BTCUSDT");
    const p = Number(j.price);
    if (p) return { price: p };
  } catch { /* fall through to CoinGecko */ }
  return { price: await coingeckoPrice() };
});

/** Server-side 1m klines for the chart, with a CoinGecko-based synthetic fallback. */
export const marketKlines = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const rows = await binance("/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=100");
    if (Array.isArray(rows) && rows.length) {
      return {
        candles: rows.map((k: (string | number)[]) => ({
          time: Math.floor(Number(k[0]) / 1000), open: Number(k[1]), high: Number(k[2]), low: Number(k[3]), close: Number(k[4]),
        })),
      };
    }
    throw new Error("empty");
  } catch {
    // CoinGecko market_chart fallback: synthesize 1m candles from 5-min points
    const r = await fetch("https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=1", { headers: { accept: "application/json" } });
    if (!r.ok) throw new Error("Market unavailable");
    const j = await r.json();
    const pts: [number, number][] = j?.prices ?? [];
    if (!pts.length) throw new Error("Market unavailable");
    const candles = pts.slice(-100).map(([t, p]) => ({ time: Math.floor(t / 1000), open: p, high: p, low: p, close: p }));
    return { candles };
  }
});

const COINS = ["BTC","ETH","BNB","SOL","XRP","DOGE","ADA","SHIB","PEPE","LTC","TRX","AVAX","LINK","DOT","MATIC"] as const;

export type Ticker = { symbol: string; name?: string; image?: string; price: number; change: number; high: number; low: number };

/** Top 100 coins by market cap via CoinGecko (server-side, no CORS), with Binance fallback. */
export const marketTickers = createServerFn({ method: "GET" }).handler(async (): Promise<{ tickers: Ticker[] }> => {
  try {
    const r = await fetch("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&price_change_percentage=24h", { headers: { accept: "application/json" } });
    if (!r.ok) throw new Error(`CoinGecko ${r.status}`);
    const rows = await r.json();
    if (Array.isArray(rows) && rows.length) {
      return {
        tickers: rows.map((c: Record<string, unknown>) => ({
          symbol: String(c["symbol"] ?? "").toUpperCase(), name: String(c["name"] ?? ""), image: String(c["image"] ?? ""),
          price: Number(c["current_price"]) || 0, change: Number(c["price_change_percentage_24h"]) || 0,
          high: Number(c["high_24h"]) || 0, low: Number(c["low_24h"]) || 0,
        })).filter((t) => t.price > 0),
      };
    }
    throw new Error("empty");
  } catch {
    /* fall back to Binance below */
  }
  try {
    const rows = await binance("/api/v3/ticker/24hr?symbols=" + encodeURIComponent(JSON.stringify(COINS.map((c) => c + "USDT"))));
    if (Array.isArray(rows) && rows.length) {
      return {
        tickers: rows.map((r: Record<string, string>) => ({
          symbol: (r["symbol"] ?? "").replace("USDT", ""), price: Number(r["lastPrice"]),
          change: Number(r["priceChangePercent"]), high: Number(r["highPrice"]), low: Number(r["lowPrice"]),
        })),
      };
    }
    throw new Error("empty");
  } catch {
    const ids = "bitcoin,ethereum,binancecoin,solana,ripple,dogecoin,cardano,shiba-inu,pepe,litecoin,tron,avalanche-2,chainlink,polkadot,matic-network";
    const r = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true`, { headers: { accept: "application/json" } });
    if (!r.ok) throw new Error("Market unavailable");
    const j = await r.json();
    const map: [string, string][] = [["BTC","bitcoin"],["ETH","ethereum"],["BNB","binancecoin"],["SOL","solana"],["XRP","ripple"],["DOGE","dogecoin"],["ADA","cardano"],["SHIB","shiba-inu"],["PEPE","pepe"],["LTC","litecoin"],["TRX","tron"],["AVAX","avalanche-2"],["LINK","chainlink"],["DOT","polkadot"],["MATIC","matic-network"]];
    return {
      tickers: map.filter(([, id]) => j[id]?.usd).map(([symbol, id]) => ({
        symbol, price: j[id].usd, change: j[id].usd_24h_change ?? 0, high: j[id].usd, low: j[id].usd,
      })),
    };
  }
});
