import type { Ticker } from "@/lib/market.functions";

// Reference snapshot shown only until live prices arrive. Marked as "delayed" in the UI.
const RAW: [string, string, number, number][] = [
  ["BTC","Bitcoin",81673.07,0.64],["ETH","Ethereum",3450.12,-1.2],["BNB","BNB",590.4,0.3],["SOL","Solana",168.2,1.1],
  ["XRP","XRP",0.58,-0.4],["DOGE","Dogecoin",0.16,2.1],["ADA","Cardano",0.45,-0.8],["SHIB","Shiba Inu",0.000024,1.5],
  ["DOT","Polkadot",6.9,-0.6],["AVAX","Avalanche",34.5,0.9],["MATIC","Polygon",0.72,-1.1],["LINK","Chainlink",15.3,0.7],
  ["LTC","Litecoin",82.1,0.2],["TRX","TRON",0.12,0.4],["PEPE","Pepe",0.0000102,3.2],["TON","Toncoin",6.4,-0.3],
  ["BCH","Bitcoin Cash",410,0.5],["NEAR","NEAR",5.8,1.4],["UNI","Uniswap",9.2,-0.9],["ATOM","Cosmos",7.8,0.1],
  ["XLM","Stellar",0.11,-0.2],["ETC","Ethereum Classic",25.6,0.6],["FIL","Filecoin",5.1,-1.3],["APT","Aptos",8.9,2.0],
  ["ARB","Arbitrum",0.95,-0.7],["OP","Optimism",2.1,1.0],["INJ","Injective",24.3,1.8],["SUI","Sui",1.2,2.4],
  ["HBAR","Hedera",0.08,-0.5],["VET","VeChain",0.03,0.3],["ICP","Internet Computer",11.2,-1.0],["AAVE","Aave",98,0.8],
  ["MKR","Maker",2400,-0.4],["GRT","The Graph",0.21,1.2],["ALGO","Algorand",0.17,-0.3],["SAND","The Sandbox",0.42,0.9],
  ["MANA","Decentraland",0.4,0.5],["AXS","Axie Infinity",7.1,-0.8],["FTM","Fantom",0.7,1.6],["EGLD","MultiversX",38,-0.2],
  ["THETA","Theta",1.9,0.4],["XTZ","Tezos",0.9,-0.6],["EOS","EOS",0.75,0.2],["FLOW","Flow",0.8,-0.9],["CHZ","Chiliz",0.1,1.1],
  ["CRV","Curve",0.5,-1.4],["RUNE","THORChain",5.6,2.2],["KAVA","Kava",0.6,0.3],["SEI","Sei",0.55,1.7],["TIA","Celestia",9.8,-2.0],
  ["WLD","Worldcoin",2.6,1.9],["FET","Fetch.ai",1.5,2.8],["RNDR","Render",7.4,1.3],["IMX","Immutable",2.0,-0.5],
  ["STX","Stacks",2.1,0.6],["LDO","Lido DAO",2.0,-0.7],["QNT","Quant",95,0.2],["GALA","Gala",0.04,1.0],["ENS","ENS",22,-0.3],
  ["1INCH","1inch",0.42,0.4],["ZEC","Zcash",30,-0.4],["DASH","Dash",28,0.1],["NEO","NEO",14,-0.6],["IOTA","IOTA",0.23,0.5],
  ["ZIL","Zilliqa",0.025,-0.2],["BAT","Basic Attention",0.24,0.3],["COMP","Compound",58,-0.9],["SNX","Synthetix",2.6,1.1],
  ["SUSHI","SushiSwap",1.1,-0.5],["YFI","yearn.finance",7400,0.2],["CAKE","PancakeSwap",2.7,0.8],["KSM","Kusama",30,-1.1],
  ["ROSE","Oasis",0.1,0.6],["ONE","Harmony",0.02,-0.4],["CELO","Celo",0.8,0.3],["ANKR","Ankr",0.04,1.0],["ENJ","Enjin",0.3,-0.2],
  ["LRC","Loopring",0.25,0.4],["ZRX","0x",0.5,-0.6],["RVN","Ravencoin",0.03,0.9],["ICX","ICON",0.25,-0.3],["ONT","Ontology",0.3,0.2],
  ["WAVES","Waves",1.8,-0.7],["QTUM","Qtum",3.2,0.5],["SKL","SKALE",0.08,1.2],["STORJ","Storj",0.5,-0.4],["AUDIO","Audius",0.2,0.6],
  ["MASK","Mask Network",3.1,1.4],["JASMY","JasmyCoin",0.03,2.0],["BONK","Bonk",0.000025,3.0],["FLOKI","Floki",0.00018,2.6],
  ["WIF","dogwifhat",2.4,4.1],["JUP","Jupiter",1.0,-1.2],["PYTH","Pyth",0.45,0.8],["ORDI","ORDI",38,-1.5],["BLUR","Blur",0.3,0.4],
  ["DYDX","dYdX",1.9,-0.8],["GMX","GMX",28,0.3],["PENDLE","Pendle",5.2,1.6],["ENA","Ethena",0.6,2.3],["STRK","Starknet",0.6,-0.9],
];

export const COINS_FALLBACK: Ticker[] = RAW.map(([symbol, name, price, change]) => ({
  symbol, name, price, change, high: price * 1.02, low: price * 0.98,
}));
