export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      audit_log: {
        Row: {
          action: string
          actor: string | null
          created_at: string
          detail: string | null
          id: string
          target_id: string | null
        }
        Insert: {
          action: string
          actor?: string | null
          created_at?: string
          detail?: string | null
          id?: string
          target_id?: string | null
        }
        Update: {
          action?: string
          actor?: string | null
          created_at?: string
          detail?: string | null
          id?: string
          target_id?: string | null
        }
        Relationships: []
      }
      bonuses: {
        Row: {
          amount: number
          created_at: string
          expires_at: string
          id: string
          reason: string
          status: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          expires_at?: string
          id?: string
          reason?: string
          status?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          expires_at?: string
          id?: string
          reason?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      deposits: {
        Row: {
          amount: number
          created_at: string
          id: string
          note: string | null
          reviewed_at: string | null
          screenshot_path: string
          status: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          note?: string | null
          reviewed_at?: string | null
          screenshot_path: string
          status?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          note?: string | null
          reviewed_at?: string | null
          screenshot_path?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          read: boolean
          target_email: string | null
          title: string
          type: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          read?: boolean
          target_email?: string | null
          title: string
          type?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          read?: boolean
          target_email?: string | null
          title?: string
          type?: string
          user_id?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          blocked: boolean
          created_at: string
          email: string | null
          id: string
          name: string
          referral_code: string
          referred_by: string | null
        }
        Insert: {
          avatar_url?: string | null
          blocked?: boolean
          created_at?: string
          email?: string | null
          id: string
          name?: string
          referral_code: string
          referred_by?: string | null
        }
        Update: {
          avatar_url?: string | null
          blocked?: boolean
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          referral_code?: string
          referred_by?: string | null
        }
        Relationships: []
      }
      settings: {
        Row: {
          app_name: string
          auto_approve_limit: number
          bep20_address: string
          deposit_instructions: string
          icon_192_url: string | null
          icon_512_url: string | null
          id: number
          logo_url: string | null
          max_deposit: number
          max_trade: number
          max_withdraw: number
          min_deposit: number
          min_trade: number
          min_withdraw: number
          profit_percent: number
          referral_bonus: number
          updated_at: string
          withdraw_days: number[]
          withdraw_end: string
          withdraw_fee_fixed: number
          withdraw_fee_percent: number
          withdraw_instructions: string
          withdraw_start: string
          withdraw_timezone: string
        }
        Insert: {
          app_name?: string
          auto_approve_limit?: number
          bep20_address?: string
          deposit_instructions?: string
          icon_192_url?: string | null
          icon_512_url?: string | null
          id?: number
          logo_url?: string | null
          max_deposit?: number
          max_trade?: number
          max_withdraw?: number
          min_deposit?: number
          min_trade?: number
          min_withdraw?: number
          profit_percent?: number
          referral_bonus?: number
          updated_at?: string
          withdraw_days?: number[]
          withdraw_end?: string
          withdraw_fee_fixed?: number
          withdraw_fee_percent?: number
          withdraw_instructions?: string
          withdraw_start?: string
          withdraw_timezone?: string
        }
        Update: {
          app_name?: string
          auto_approve_limit?: number
          bep20_address?: string
          deposit_instructions?: string
          icon_192_url?: string | null
          icon_512_url?: string | null
          id?: number
          logo_url?: string | null
          max_deposit?: number
          max_trade?: number
          max_withdraw?: number
          min_deposit?: number
          min_trade?: number
          min_withdraw?: number
          profit_percent?: number
          referral_bonus?: number
          updated_at?: string
          withdraw_days?: number[]
          withdraw_end?: string
          withdraw_fee_fixed?: number
          withdraw_fee_percent?: number
          withdraw_instructions?: string
          withdraw_start?: string
          withdraw_timezone?: string
        }
        Relationships: []
      }
      support_messages: {
        Row: {
          body: string
          category: string | null
          created_at: string
          id: string
          image_path: string | null
          sender: string
          user_id: string
        }
        Insert: {
          body?: string
          category?: string | null
          created_at?: string
          id?: string
          image_path?: string | null
          sender?: string
          user_id: string
        }
        Update: {
          body?: string
          category?: string | null
          created_at?: string
          id?: string
          image_path?: string | null
          sender?: string
          user_id?: string
        }
        Relationships: []
      }
      support_tickets: {
        Row: {
          admin_reply: string | null
          category: string
          created_at: string
          id: string
          image_path: string | null
          message: string
          status: string
          subject: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_reply?: string | null
          category?: string
          created_at?: string
          id?: string
          image_path?: string | null
          message: string
          status?: string
          subject: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_reply?: string | null
          category?: string
          created_at?: string
          id?: string
          image_path?: string | null
          message?: string
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      swaps: {
        Row: {
          created_at: string
          fee: number
          from_amount: number
          from_symbol: string
          id: string
          rate: number
          to_amount: number
          to_symbol: string
          user_id: string
        }
        Insert: {
          created_at?: string
          fee?: number
          from_amount: number
          from_symbol: string
          id?: string
          rate: number
          to_amount: number
          to_symbol: string
          user_id: string
        }
        Update: {
          created_at?: string
          fee?: number
          from_amount?: number
          from_symbol?: string
          id?: string
          rate?: number
          to_amount?: number
          to_symbol?: string
          user_id?: string
        }
        Relationships: []
      }
      trades: {
        Row: {
          amount: number
          close_price: number | null
          duration_seconds: number
          expires_at: string
          id: string
          open_price: number
          opened_at: string
          payout: number
          profit: number
          side: string
          status: string
          user_id: string
        }
        Insert: {
          amount: number
          close_price?: number | null
          duration_seconds: number
          expires_at: string
          id?: string
          open_price: number
          opened_at?: string
          payout?: number
          profit?: number
          side: string
          status?: string
          user_id: string
        }
        Update: {
          amount?: number
          close_price?: number | null
          duration_seconds?: number
          expires_at?: string
          id?: string
          open_price?: number
          opened_at?: string
          payout?: number
          profit?: number
          side?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      wallet_assets: {
        Row: {
          qty: number
          symbol: string
          updated_at: string
          user_id: string
        }
        Insert: {
          qty?: number
          symbol: string
          updated_at?: string
          user_id: string
        }
        Update: {
          qty?: number
          symbol?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      wallets: {
        Row: {
          balance: number
          is_paid: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          is_paid?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          is_paid?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      withdrawals: {
        Row: {
          address: string
          amount: number
          created_at: string
          fee: number
          id: string
          note: string | null
          reviewed_at: string | null
          status: string
          user_id: string
        }
        Insert: {
          address: string
          amount: number
          created_at?: string
          fee?: number
          id?: string
          note?: string | null
          reviewed_at?: string | null
          status?: string
          user_id: string
        }
        Update: {
          address?: string
          amount?: number
          created_at?: string
          fee?: number
          id?: string
          note?: string | null
          reviewed_at?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_give_bonus: {
        Args: { _amount: number; _email: string; _reason: string }
        Returns: string
      }
      admin_send_notification: {
        Args: { _email: string; _message: string; _title: string }
        Returns: string
      }
      claim_bonus: { Args: { _id: string }; Returns: undefined }
      create_deposit: {
        Args: { _amount: number; _screenshot: string }
        Returns: string
      }
      do_swap: {
        Args: {
          _amount: number
          _from: string
          _from_price: number
          _to: string
          _to_price: number
          _user: string
        }
        Returns: string
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      open_trade: {
        Args: {
          _amount: number
          _duration: number
          _price: number
          _side: string
          _user: string
        }
        Returns: {
          amount: number
          close_price: number | null
          duration_seconds: number
          expires_at: string
          id: string
          open_price: number
          opened_at: string
          payout: number
          profit: number
          side: string
          status: string
          user_id: string
        }
        SetofOptions: {
          from: "*"
          to: "trades"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      referral_exists: { Args: { _code: string }; Returns: boolean }
      request_withdrawal: {
        Args: { _address: string; _amount: number }
        Returns: string
      }
      review_deposit: {
        Args: { _approve: boolean; _id: string }
        Returns: undefined
      }
      review_withdrawal: {
        Args: { _approve: boolean; _id: string }
        Returns: undefined
      }
      set_user_blocked: {
        Args: { _blocked: boolean; _user: string }
        Returns: undefined
      }
      settle_trade: {
        Args: { _close: number; _id: string }
        Returns: {
          amount: number
          close_price: number | null
          duration_seconds: number
          expires_at: string
          id: string
          open_price: number
          opened_at: string
          payout: number
          profit: number
          side: string
          status: string
          user_id: string
        }
        SetofOptions: {
          from: "*"
          to: "trades"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      write_audit: {
        Args: { _action: string; _detail: string; _target: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
