<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Reuse session reads and Query-cached profile access checks for authenticated navigation; backend RLS remains authoritative, avoiding repeated blocking auth requests.
- Keep short-lived query caches and intent-based route preloading for fast repeat navigation; invalidate affected queries after writes.
- Load the dashboard chart lazily without changing its feed or rendering logic, so chart code does not block other screens.
- Keep live greeting time updates in a memoized component and derive activity from existing trade state, avoiding additional account queries.
